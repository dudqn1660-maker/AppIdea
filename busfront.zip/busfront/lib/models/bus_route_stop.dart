// lib/models/bus_route_stop.dart

class BusRouteStop {
  final String? routeId;
  final String? routeName;
  final String? routeType;

  final String stationId;
  final String stationName;
  final int stationOrder;
  final bool isTurnPoint;

  // ⭐️ [추천] 정류장 고유 번호 (ARS-ID, 예: 02145) 추가
  final String? mobileNo;

  // 지도 표시를 위한 좌표
  final double latitude;
  final double longitude;

  BusRouteStop({
    required this.stationId,
    required this.stationName,
    required this.stationOrder,
    required this.isTurnPoint,
    this.routeId,
    this.routeName,
    this.routeType,
    this.mobileNo, // ⭐️ 생성자 추가
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory BusRouteStop.fromJson(Map<String, dynamic> json) {
    return BusRouteStop(
      routeId: json['routeId']?.toString(),
      routeName: json['routeName']?.toString() ?? '이름 없음',
      routeType: json['routeType']?.toString(),

      stationId: json['stationId'].toString(),
      stationName: json['stationName'] as String? ?? '이름 없음',
      stationOrder: json['stationOrder'] as int? ?? 0,
      isTurnPoint: json['isTurnPoint'] as bool? ?? false,

      // ⭐️ JSON 파싱 추가 (백엔드에서 mobileNo 혹은 arsId로 주는지 확인 필요)
      mobileNo: json['mobileNo']?.toString() ?? json['arsId']?.toString(),

      // 좌표 파싱
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
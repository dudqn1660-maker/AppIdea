import 'package:flutter/material.dart';
import 'package:bus/screens/main_screen.dart'; // ⭐️ Import 확인: 이 줄이 있어야 MainScreen() 에러가 해결됩니다.

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // ⭐️ [NEW] 앱의 새로운 메인 컬러
  static const MaterialColor primaryBlue = MaterialColor(
    0xFF007AFF, // (기본 007AFF - 딥 스카이 블루)
    <int, Color>{
      50: Color(0xFFE0F1FF),
      100: Color(0xFFB3DAFF),
      200: Color(0xFF80C3FF),
      300: Color(0xFF4DAFFF),
      400: Color(0xFF269FFF),
      500: Color(0xFF007AFF), // ⭐️ 여기가 PrimaryColor
      600: Color(0xFF0070F0),
      700: Color(0xFF0063D6),
      800: Color(0xFF0058BC),
      900: Color(0xFF004599),
    },
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '경기 버스 알리미',
      theme: ThemeData(
        primarySwatch: primaryBlue,
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),

        appBarTheme: const AppBarTheme(
          elevation: 0,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black87,
          iconTheme: IconThemeData(color: Colors.black87),
          titleTextStyle: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),

        // ⭐️ [수정 완료] CardThemeData를 사용합니다.
        cardTheme: const CardThemeData(
          color: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
              Radius.circular(16),
            ),
          ),
        ),

        // 하단 탭바 테마
        bottomNavigationBarTheme: BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          selectedItemColor: primaryBlue,
          unselectedItemColor: Colors.grey[500],
          elevation: 10,
          type: BottomNavigationBarType.fixed,
          showUnselectedLabels: true,

          selectedLabelStyle: const TextStyle(fontSize: 12),
          unselectedLabelStyle: const TextStyle(fontSize: 12),
        ),

        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // ⭐️ [수정 완료] const 제거 및 괄호 호출 (에러 해결)
      home: MainScreen(),
    );
  }
}
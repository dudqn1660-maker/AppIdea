import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:bus/services/place_service.dart';

// 저장할 경로 모델
class FavoriteRoute {
  final String id;
  final String name; // 예: "집으로", "회사 가는 길"
  final Place start;
  final Place end;

  FavoriteRoute({
    required this.id,
    required this.name,
    required this.start,
    required this.end,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'start': {
      'place_name': start.placeName, 'address_name': start.address, 'y': start.lat.toString(), 'x': start.lng.toString()
    },
    'end': {
      'place_name': end.placeName, 'address_name': end.address, 'y': end.lat.toString(), 'x': end.lng.toString()
    },
  };

  factory FavoriteRoute.fromJson(Map<String, dynamic> json) => FavoriteRoute(
    id: json['id'],
    name: json['name'],
    start: Place.fromJson(json['start']),
    end: Place.fromJson(json['end']),
  );
}

class RouteFavoriteService {
  static const _key = 'favorite_routes';

  Future<List<FavoriteRoute>> getRoutes() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_key) ?? [];
    return list.map((e) => FavoriteRoute.fromJson(jsonDecode(e))).toList();
  }

  Future<void> addRoute(FavoriteRoute route) async {
    final prefs = await SharedPreferences.getInstance();
    final routes = await getRoutes();
    routes.add(route);
    await prefs.setStringList(_key, routes.map((e) => jsonEncode(e.toJson())).toList());
  }

  Future<void> removeRoute(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final routes = await getRoutes();
    routes.removeWhere((e) => e.id == id);
    await prefs.setStringList(_key, routes.map((e) => jsonEncode(e.toJson())).toList());
  }
}
import 'dart:typed_data'; // ⭐️ 이거 꼭 필요합니다!
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin =
  FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const AndroidInitializationSettings androidSettings =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings settings =
    InitializationSettings(android: androidSettings);

    await _notificationsPlugin.initialize(settings);
  }

  static Future<void> showNotification({
    required String title,
    required String body,
  }) async {
    // ⭐️ [수정] 여기에 'const'를 빼야 합니다! (vibrationPattern 때문에 상수가 될 수 없음)
    final AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'bus_alert_channel_id', // 채널 ID
      '버스 승하차 알림', // 채널 이름
      channelDescription: '버스 승차 및 하차 알림을 위한 채널입니다.',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      enableVibration: true,
      // 징-징- 패턴 (대기 0ms, 진동 1000ms, 쉬고 500ms, 진동 1000ms)
      vibrationPattern: Int64List.fromList([0, 1000, 500, 1000]),
      playSound: true,
    );

    final NotificationDetails details =
    NotificationDetails(android: androidDetails);

    await _notificationsPlugin.show(
      DateTime.now().millisecond, // 유니크 ID
      title,
      body,
      details,
    );
  }
}
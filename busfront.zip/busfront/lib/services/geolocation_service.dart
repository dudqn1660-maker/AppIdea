import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:bus/services/place_service.dart'; // Place 모델과 API 키 가져오기

class GeolocationService {
  // PlaceService에 있는 키를 사용
  static const String _kakaoApiKey = PlaceService.kakaoApiKey;

  // 1. 현재 GPS 좌표 가져오기
  Future<Position> getCurrentPosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('위치 서비스를 활성화해주세요.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('위치 권한이 거부되었습니다.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('위치 권한이 영구적으로 거부되었습니다.');
    }

    return await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  // 2. 좌표 -> 장소명 변환 (카카오 API 사용)
  Future<Place> getCurrentLocationAsPlace() async {
    try {
      final position = await getCurrentPosition();

      final url = 'https://dapi.kakao.com/v2/local/geo/coord2address.json?x=${position.longitude}&y=${position.latitude}';

      final response = await http.get(
        Uri.parse(url),
        headers: {'Authorization': _kakaoApiKey},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final List documents = data['documents'];

        if (documents.isEmpty) {
          return Place(
            placeName: "알 수 없는 위치",
            address: "주소 정보 없음",
            lat: position.latitude,
            lng: position.longitude,
            // id 필드 삭제함
          );
        }

        final addressInfo = documents[0];
        String placeName = "";
        String address = "";

        // (1) 도로명 주소 분석
        if (addressInfo['road_address'] != null) {
          final road = addressInfo['road_address'];
          address = road['address_name'] ?? "";

          // 건물명이 있으면 그걸 장소명으로 사용 (예: 신구대학교)
          if (road['building_name'] != null && road['building_name'].toString().isNotEmpty) {
            placeName = road['building_name'];
          }
        }

        // (2) 지번 주소 분석 (도로명이 없거나 건물명을 못 찾았을 때)
        if (addressInfo['address'] != null) {
          final jibun = addressInfo['address'];
          if (address.isEmpty) address = jibun['address_name'] ?? "";

          if (placeName.isEmpty) {
            placeName = "내 위치 (${jibun['region_3depth_name'] ?? '주변'})";
          }
        }

        // 그래도 비어있으면 기본값
        if (placeName.isEmpty) placeName = "현재 위치";

        return Place(
          placeName: placeName,
          address: address,
          lat: position.latitude,
          lng: position.longitude,
          // id 필드 삭제함
        );
      } else {
        throw Exception('카카오 API 오류');
      }
    } catch (e) {
      // 에러 발생 시 좌표만이라도 반환
      return Place(
        placeName: "위치 확인 불가",
        address: "GPS 오류",
        lat: 0.0,
        lng: 0.0,
        // id 필드 삭제함
      );
    }
  }
}
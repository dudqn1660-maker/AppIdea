import 'package:flutter/foundation.dart';
import 'package:bus/models/bus_arrival_info.dart';

class NavigationStateService extends ChangeNotifier {
  // 싱글톤 패턴 유지
  static final NavigationStateService _instance = NavigationStateService._internal();
  factory NavigationStateService() => _instance;
  NavigationStateService._internal();

  // 안내 중 여부
  bool _isNavigating = false;
  bool get isNavigating => _isNavigating;

  // 현재 안내 중인 버스 정보
  BusArrivalInfo? _currentBus;
  BusArrivalInfo? get currentBus => _currentBus;

  // ⭐️ [추가됨] 출발 정류장 이름 저장
  String? _startStation;
  String? get startStation => _startStation;

  // 도착 정류장 이름 저장
  String? _endStation;
  String? get endStation => _endStation;

  // 탑승 여부 상태
  bool _isBoarded = false;
  bool get isBoarded => _isBoarded;

  // 탑승 상태 변경 함수
  void setBoarded(bool value) {
    _isBoarded = value;
    notifyListeners();
  }

  // ⭐️ [수정됨] 안내 시작 함수: startStation 인자 추가 및 저장
  void startNavigation(BusArrivalInfo bus, String startStation, String endStation) {
    _isNavigating = true;
    _currentBus = bus;
    _startStation = startStation; // 출발지 저장
    _endStation = endStation;
    _isBoarded = false; // 새로 시작할 땐 탑승 안 함으로 초기화
    notifyListeners();
  }

  // 안내 종료 함수
  void stopNavigation() {
    _isNavigating = false;
    _currentBus = null;
    _startStation = null; // 출발지 초기화
    _endStation = null;
    _isBoarded = false; // 종료 시 초기화
    notifyListeners();
  }
}
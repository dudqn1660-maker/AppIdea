// lib/services/bus_api_service.dart

import 'package:http/http.dart' as http;
import 'dart:convert';
// (경로와 프로젝트 이름 확인)
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
// '버스 위치' 모델 import
import 'package:bus/models/bus_location.dart';

class BusApiService {
  // ⭐️ [수정!] static const로 변경하여 재시작 시점에 확실히 로드되도록 합니다.
  // 이 IP 주소를 ipconfig로 확인한 현재 PC의 IPv4 주소로 변경했는지 다시 한번 확인하세요.
  static const String _baseUrl = 'http://192.168.0.16:8080/api';

  // 만약 서버 포트가 8080이 아니라면 해당 포트 번호로 변경해야 합니다.

  // 1. (진짜) 정류소 이름으로 검색하는 함수
  Future<List<BusStation>> searchStation(String stationName) async {
    // ⭐️ _baseUrl에 static 키워드가 붙었으므로, 클래스를 통해 접근합니다.
    final String url = '$_baseUrl/stations/search?keyword=$stationName';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);
        return jsonList.map((item) => BusStation.fromJson(item)).toList();
      } else {
        throw Exception('정류소 검색 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('정류소 검색 중 에러: $e');
    }
  }

  // 2. (진짜) 정류소 ID로 버스 도착 정보를 가져오는 함수
  Future<List<BusArrivalInfo>> fetchBusArrival(String stationId) async {
    final String url = '$_baseUrl/stations/$stationId/arrivals';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusArrivalInfo.fromJson(item)).toList();
      } else {
        throw Exception('버스 도착 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 도착 정보 로딩 중 에러: $e');
    }
  }

  // 2-1. 특정 노선의 도착 정보를 가져오는 함수
  Future<BusArrivalInfo?> fetchArrivalInfoByRoute({
    required String stationId,
    required String routeId,
  }) async {
    final String url = '$_baseUrl/stations/$stationId/arrivals/route/$routeId';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final Map<String, dynamic> jsonMap = jsonDecode(decodedBody);

        return BusArrivalInfo.fromJson(jsonMap);
      } else if (response.statusCode == 404 || response.statusCode == 204) {
        // 도착 정보가 없는 경우
        return null;
      } else {
        throw Exception('특정 노선 도착 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('특정 노선 도착 정보 로딩 중 에러: $e');
    }
  }

  // 2-2. 두 정류장 사이의 공통 노선 목록을 가져오는 함수
  Future<List<BusRouteStop>> getRouteBuses({
    required String startStationId,
    required String endStationId,
  }) async {
    final String url = '$_baseUrl/routes/common?startStationId=$startStationId&endStationId=$endStationId';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusRouteStop.fromJson(item)).toList();
      } else {
        throw Exception('경로 노선 목록 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('경로 노선 목록 로딩 중 에러: $e');
    }
  }

  // 3. 노선 ID로 정류소 목록을 가져오는 함수
  Future<List<BusRouteStop>> getBusRoute(String routeId) async {
    final String url = '$_baseUrl/routes/$routeId/stops';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusRouteStop.fromJson(item)).toList();
      } else {
        throw Exception('버스 노선 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 노선 정보 로딩 중 에러: $e');
    }
  }

  // 4. 노선 ID로 '실시간 버스 위치' 목록을 가져오는 함수
  Future<List<BusLocation>> getBusLocations(String routeId) async {
    final String url = '$_baseUrl/routes/$routeId/locations';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusLocation.fromJson(item)).toList();
      } else {
        throw Exception('버스 위치 정보 로딩 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('버스 위치 정보 로딩 중 에러: $e');
    }
  }

  // 5. 위도/경도로 주변 정류소 목록을 가져오는 함수
  Future<List<BusStation>> searchNearbyStations(double lat, double lon, int radius) async {
    final String url = '$_baseUrl/stations/nearby?lat=$lat&lon=$lon&radius=$radius';

    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final decodedBody = utf8.decode(response.bodyBytes);
        final List<dynamic> jsonList = jsonDecode(decodedBody);

        return jsonList.map((item) => BusStation.fromJson(item)).toList();
      } else {
        throw Exception('주변 정류소 검색 실패! (코드: ${response.statusCode})');
      }
    } catch (e) {
      throw Exception('주변 정류소 검색 중 에러: $e');
    }
  }
}
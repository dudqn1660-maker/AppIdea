// lib/screens/destination_map_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';
import 'package:bus/services/place_service.dart'; // ⭐️ Place 모델 사용을 위해

class DestinationMapScreen extends StatefulWidget {
  final Place destination; // ⭐️ BusStation 대신 Place를 받음

  const DestinationMapScreen({Key? key, required this.destination}) : super(key: key);

  @override
  State<DestinationMapScreen> createState() => _DestinationMapScreenState();
}

class _DestinationMapScreenState extends State<DestinationMapScreen> {
  final BusApiService _apiService = BusApiService();
  final MapController _mapController = MapController();
  List<BusStation> _nearbyStations = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadNearbyStations();
  }

  Future<void> _loadNearbyStations() async {
    try {
      // ⭐️ 장소의 좌표(lat, lng)를 사용하여 -> 내 백엔드 서버에 주변 정류소를 요청
      final stations = await _apiService.searchNearbyStations(
        widget.destination.lat,
        widget.destination.lng,
        500, // 반경 500m
      );
      setState(() {
        _nearbyStations = stations;
        _isLoading = false;
      });
    } catch (e) {
      print("주변 정류소 로드 실패: $e");
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.destination.placeName)),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              // ⭐️ 장소 좌표를 중심으로 지도 시작
              initialCenter: LatLng(widget.destination.lat, widget.destination.lng),
              initialZoom: 16.0,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.bus',
              ),
              MarkerLayer(
                markers: [
                  // 1. 🚩 목적지(장소) 마커
                  Marker(
                    point: LatLng(widget.destination.lat, widget.destination.lng),
                    width: 60,
                    height: 60,
                    child: Column(
                      children: [
                        const Icon(Icons.flag_circle, color: Colors.red, size: 40),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: [BoxShadow(blurRadius: 4, color: Colors.black26)],
                          ),
                          child: const Text("도착", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                        )
                      ],
                    ),
                  ),

                  // 2. 🚌 주변 정류소 마커들
                  ..._nearbyStations.map((station) {
                    return Marker(
                      point: LatLng(station.latitude, station.longitude),
                      width: 40,
                      height: 40,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: station)),
                          );
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.9),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.blue, width: 2),
                          ),
                          child: const Icon(Icons.directions_bus, color: Colors.blue, size: 20),
                        ),
                      ),
                    );
                  }).toList(),
                ],
              ),
            ],
          ),

          // 하단 정보창
          if (!_isLoading)
            Positioned(
              bottom: 20,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2)],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "'${widget.destination.placeName}' 주변",
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "반경 500m 내 버스 정류장 ${_nearbyStations.length}개 발견",
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
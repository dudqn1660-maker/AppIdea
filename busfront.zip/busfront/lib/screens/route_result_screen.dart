import 'package:flutter/material.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/place_service.dart';
import 'package:bus/screens/bus_route_screen.dart';
import 'package:collection/collection.dart';
import 'package:latlong2/latlong.dart';

class RouteResultScreen extends StatefulWidget {
  final Place startPlace;
  final Place endPlace;

  const RouteResultScreen({
    Key? key,
    required this.startPlace,
    required this.endPlace,
  }) : super(key: key);

  @override
  State<RouteResultScreen> createState() => _RouteResultScreenState();
}

class _RouteResultScreenState extends State<RouteResultScreen> {
  final BusApiService _apiService = BusApiService();
  final Distance _distanceCalculator = const Distance();

  bool _isLoading = true;
  String _statusMessage = "최적의 경로 분석 중...";

  final Map<String, List<BusRouteStop>> _routeCache = {};
  List<Map<String, dynamic>> _foundRoutes = [];

  @override
  void initState() {
    super.initState();
    _analyzeRoute();
  }

  void _onRefresh() {
    setState(() {
      _isLoading = true;
      _foundRoutes.clear();
      _statusMessage = "경로 재탐색 중...";
    });
    _analyzeRoute();
  }

  String _normalizeName(String name) {
    return name.replaceAll(' ', '')
        .replaceAll('초등학교', '').replaceAll('중학교', '').replaceAll('고등학교', '')
        .replaceAll('대학교', '대').replaceAll('대학', '대').replaceAll('학교', '')
        .replaceAll('역', '').replaceAll('.', '');
  }

  // 남은 정거장 수 파싱 헬퍼
  int _parseRemainingStops(BusArrivalInfo bus) {
    if (bus.locationNo1 != null) return bus.locationNo1!;

    // locationNo1이 없으면 문자열에서 "N번째" 파싱
    if (bus.arrivalInfo != null) {
      final RegExp regExp = RegExp(r'(\d+)번째');
      final match = regExp.firstMatch(bus.arrivalInfo!);
      if (match != null) {
        return int.tryParse(match.group(1)!) ?? 0;
      }
    }
    return 0;
  }

  Future<void> _analyzeRoute() async {
    try {
      const int searchRadius = 800;

      final results = await Future.wait([
        _apiService.searchNearbyStations(widget.startPlace.lat, widget.startPlace.lng, searchRadius),
        _apiService.searchNearbyStations(widget.endPlace.lat, widget.endPlace.lng, searchRadius),
      ]);

      final startStations = results[0];
      final endStations = results[1];

      if (startStations.isEmpty || endStations.isEmpty) {
        _finishSearch("근처에 버스 정류장이 없습니다.");
        return;
      }

      final startCandidates = startStations.take(30).toList();
      final endCandidateIds = endStations.map((e) => e.stationId).toSet();
      final String endPlaceNameClean = _normalizeName(widget.endPlace.placeName);

      final List<List<BusArrivalInfo>> allArrivals = await Future.wait(
          startCandidates.map((station) => _apiService.fetchBusArrival(station.stationId))
      );

      Map<BusArrivalInfo, List<BusStation>> busToStartStations = {};
      for (int i = 0; i < startCandidates.length; i++) {
        final station = startCandidates[i];
        for (var bus in allArrivals[i]) {
          if (bus.routeId == null) continue;
          busToStartStations.putIfAbsent(bus, () => []).add(station);
        }
      }

      final busList = busToStartStations.keys.toList();
      Map<String, Map<String, dynamic>> bestRoutesMap = {};

      const int batchSize = 10;
      for (int i = 0; i < busList.length; i += batchSize) {
        if (!mounted) return;
        final end = (i + batchSize < busList.length) ? i + batchSize : busList.length;
        final batch = busList.sublist(i, end);

        final futures = batch.map((bus) async {
          final routeStops = _routeCache[bus.routeId] ?? await _apiService.getBusRoute(bus.routeId!);
          if (routeStops.isNotEmpty) _routeCache[bus.routeId!] = routeStops;
          return routeStops;
        });

        final results = await Future.wait(futures);

        for (int j = 0; j < batch.length; j++) {
          final bus = batch[j];
          final routeStops = results[j] as List<BusRouteStop>;
          final possibleStartStations = busToStartStations[bus];

          if (routeStops.isEmpty || possibleStartStations == null) continue;

          for (var startStation in possibleStartStations) {
            final double distFromStart = _distanceCalculator.as(
                LengthUnit.Meter,
                LatLng(widget.startPlace.lat, widget.startPlace.lng),
                LatLng(startStation.latitude, startStation.longitude)
            );

            List<int> startIndices = [];
            String startNormal = _normalizeName(startStation.stationName);
            for (int k = 0; k < routeStops.length; k++) {
              if (routeStops[k].stationId == startStation.stationId || _normalizeName(routeStops[k].stationName) == startNormal) {
                startIndices.add(k);
              }
            }

            List<int> endIndices = [];
            for (int k = 0; k < routeStops.length; k++) {
              final stop = routeStops[k];
              bool isMatch = endCandidateIds.contains(stop.stationId);
              if (!isMatch) {
                String stopNameClean = _normalizeName(stop.stationName);
                if (stopNameClean.contains(endPlaceNameClean) || endPlaceNameClean.contains(stopNameClean)) {
                  isMatch = true;
                }
              }
              if (isMatch) endIndices.add(k);
            }

            for (int sIdx in startIndices) {
              for (int eIdx in endIndices) {
                if (eIdx > sIdx) {
                  int distance = eIdx - sIdx;
                  final uniqueKey = bus.routeId!;

                  double walkTime = distFromStart / 60.0;

                  // ⭐️ [수정 1] 시간 보정 로직 (Sanity Check)
                  int waitTime;
                  int remainingStops = _parseRemainingStops(bus); // 남은 정거장 수

                  if (bus.predictTime != null) {
                    waitTime = bus.predictTime!;

                    // 🚨 핵심 보정: 정거장은 3개 이상 남았는데, 시간은 5분 미만이면 -> 정거장 기준(2분/개)으로 강제 보정
                    if (remainingStops >= 3 && waitTime < 5) {
                      waitTime = remainingStops * 2;
                    }
                  } else {
                    waitTime = _parseTime(bus.arrivalInfo ?? '999');
                  }

                  double rideTime = distance * 1.5;
                  double totalScore = (walkTime * 1.2) + waitTime + rideTime;

                  bool shouldUpdate = false;

                  if (!bestRoutesMap.containsKey(uniqueKey)) {
                    shouldUpdate = true;
                  } else {
                    double existingScore = bestRoutesMap[uniqueKey]!['score'] ?? 999999.0;
                    if (totalScore < existingScore) {
                      shouldUpdate = true;
                    }
                  }

                  if (shouldUpdate) {
                    final realStartStop = routeStops[sIdx];
                    final realEndStop = routeStops[eIdx];

                    bestRoutesMap[uniqueKey] = {
                      'bus': bus,
                      'startStation': realStartStop.stationName,
                      'endStation': realEndStop.stationName,
                      'startStationId': realStartStop.stationId,
                      'endStationId': realEndStop.stationId,
                      'time': bus.arrivalInfo ?? '정보없음',
                      'predictTime': bus.predictTime,
                      'remainingStops': remainingStops, // 정거장 수 저장
                      'mobileNo': startStation.mobileNo,
                      'stopCount': distance,
                      'distFromStart': distFromStart,
                      'score': totalScore,
                    };
                  }
                }
              }
            }
          }
        }
      }

      _foundRoutes.addAll(bestRoutesMap.values);
      _finishSearch(null);

    } catch (e, s) {
      print("Route Analysis Error: $e");
      print("Stacktrace: $s");
      _finishSearch("오류가 발생했습니다.");
    }
  }

  void _finishSearch(String? errorMsg) {
    if (mounted) {
      setState(() {
        _isLoading = false;
        if (errorMsg != null) {
          _statusMessage = errorMsg;
        } else if (_foundRoutes.isEmpty) {
          _statusMessage = "갈 수 있는 버스가 없습니다.";
        } else {
          _sortRoutes();
          _statusMessage = "${_foundRoutes.length}개의 경로 발견";
        }
      });
    }
  }

  void _sortRoutes() {
    setState(() {
      _foundRoutes.sort((a, b) {
        bool aEnded = a['isEnded'] ?? false;
        bool bEnded = b['isEnded'] ?? false;
        if (aEnded && !bEnded) return 1;
        if (!aEnded && bEnded) return -1;

        double scoreA = a['score'] ?? 999999.0;
        double scoreB = b['score'] ?? 999999.0;

        return scoreA.compareTo(scoreB);
      });
    });
  }

  int _parseTime(String timeStr) {
    if (timeStr.contains("곧") || timeStr.contains("도착") || timeStr.contains("진입")) return 0;
    if (timeStr == "정보없음" || timeStr.contains("운행종료")) return 999;
    final num = int.tryParse(timeStr.replaceAll(RegExp(r'[^0-9]'), ''));
    return num ?? 999;
  }

  @override
  Widget build(BuildContext context) {
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('추천 경로', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _onRefresh,
          ),
        ],
      ),
      body: _isLoading
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFF3B5998)),
            const SizedBox(height: 24),
            Text(_statusMessage, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.black54)),
          ],
        ),
      )
          : Column(
        children: [
          _buildHeader(),
          Expanded(
            child: _foundRoutes.isEmpty
                ? _buildEmptyView()
                : ListView.separated(
              padding: EdgeInsets.fromLTRB(16, 20, 16, bottomPadding + 20),
              itemCount: _foundRoutes.length,
              separatorBuilder: (context, index) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                return _buildBusCard(_foundRoutes[index], isBest: index == 0);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4))],
      ),
      padding: const EdgeInsets.fromLTRB(24, 10, 24, 24),
      child: Column(
        children: [
          _buildLocationRow(isStart: true, name: widget.startPlace.placeName),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 11),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Column(
                children: List.generate(3, (index) => Container(width: 2, height: 4, margin: const EdgeInsets.symmetric(vertical: 1), color: Colors.grey[300])),
              ),
            ),
          ),
          const SizedBox(height: 4),
          _buildLocationRow(isStart: false, name: widget.endPlace.placeName),
        ],
      ),
    );
  }

  Widget _buildLocationRow({required bool isStart, required String name}) {
    return Row(
      children: [
        Container(
          width: 24, height: 24,
          decoration: BoxDecoration(
            color: isStart ? const Color(0xFFE3F2FD) : const Color(0xFFFFEBEE),
            shape: BoxShape.circle,
            border: Border.all(color: isStart ? Colors.blueAccent : Colors.redAccent, width: 2),
          ),
          child: Center(
            child: Container(width: 8, height: 8, decoration: BoxDecoration(color: isStart ? Colors.blueAccent : Colors.redAccent, shape: BoxShape.circle)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87), overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  // ⭐️ [수정 2] UI 표시 로직 변경: 시간과 정거장이 모순되면 정거장 기준 표시
  Widget _buildBusCard(Map<String, dynamic> route, {bool isBest = false}) {
    final bus = route['bus'] as BusArrivalInfo;

    int? minutes = bus.predictTime;
    String rawInfo = bus.arrivalInfo ?? '';
    // ⭐️ 저장해둔 남은 정거장 수 가져오기
    int remainingStops = route['remainingStops'] ?? 0;

    final int stopCount = route['stopCount'] ?? 0;
    final double distFromStart = route['distFromStart'] ?? 0.0;
    final int walkMin = (distFromStart / 60).round();

    bool isEnded = false;
    String displayTime = "";
    Color timeColor = Colors.grey;
    bool isUrgent = false;

    final int lastStatus = bus.lastBusStatus;

    // 운행 종료 체크
    if (bus.flag == 'STOP' || bus.flag == 'END' || rawInfo.contains('운행종료')) {
      isEnded = true;
      displayTime = "운행종료";
      timeColor = Colors.grey;
      route['isEnded'] = true;
    }
    // 숫자로 된 예상 시간이 있을 때
    else if (minutes != null) {
      // 🚨 핵심 UI 보정: 시간은 2분 이하(곧도착)인데, 정거장은 3개 이상 남았다? -> 유령 버스임
      if (remainingStops >= 3 && minutes <= 2) {
        displayTime = "$remainingStops번째 전 (약 ${remainingStops * 2}분)";
        timeColor = const Color(0xFF7F8FA6); // 덜 긴급한 색
        isUrgent = false;
      }
      // 정상적인 경우
      else if (minutes == 0) {
        displayTime = "곧 도착";
        isUrgent = true;
        timeColor = const Color(0xFFD63031);
      } else {
        displayTime = "$minutes분 후 도착";
        isUrgent = minutes < 5;
        timeColor = isUrgent ? const Color(0xFFD63031) : const Color(0xFF7F8FA6);
      }
    }
    // 문자열만 있을 때
    else if (rawInfo.isNotEmpty && rawInfo != "정보없음") {
      displayTime = rawInfo;
      timeColor = Colors.orange;
    }
    else {
      displayTime = "정보 없음";
      timeColor = Colors.grey;
    }

    return GestureDetector(
      onTap: isEnded ? null : () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BusRouteScreen(
              routeId: bus.routeId!,
              routeName: bus.routeName!,
              startStation: route['startStation'],
              endStation: route['endStation'],
              startStationId: route['startStationId'],
              endStationId: route['endStationId'],
              busInfo: bus,
              startPlace: widget.startPlace,
              endPlace: widget.endPlace,
            ),
          ),
        );
      },
      child: Opacity(
        opacity: isEnded ? 0.6 : 1.0,
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: isBest ? Border.all(color: const Color(0xFF3B5998), width: 2) : null,
            boxShadow: [BoxShadow(color: Colors.blueGrey.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: Stack(
            children: [
              if (isBest)
                Positioned(
                  top: 0, right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: const BoxDecoration(
                      color: Color(0xFF3B5998),
                      borderRadius: BorderRadius.only(topRight: Radius.circular(18), bottomLeft: Radius.circular(12)),
                    ),
                    child: const Text("가장 가까움", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                  ),
                ),
              Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: isEnded ? Colors.grey[200] : const Color(0xFFF0F4FF), borderRadius: BorderRadius.circular(12)),
                          child: Icon(Icons.directions_bus_rounded, color: isEnded ? Colors.grey : const Color(0xFF3B5998), size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text("${bus.routeName}번", style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: isEnded ? Colors.grey : const Color(0xFF2D3436))),
                              const SizedBox(width: 8),
                              if (isEnded)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.circular(4)),
                                  child: const Text("종료", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                                )
                              else if (bus.congestion != null)
                                _buildCongestionBadge(bus.congestion!),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(color: isEnded ? Colors.grey[100] : (isUrgent ? const Color(0xFFFFEBEE) : const Color(0xFFF5F6FA)), borderRadius: BorderRadius.circular(12)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.access_time_rounded, size: 16, color: timeColor),
                        const SizedBox(width: 6),
                        // ⭐️ 보정된 displayTime 표시
                        Text(displayTime, style: TextStyle(color: timeColor, fontWeight: FontWeight.bold, fontSize: 15)),

                        if (lastStatus == 2) ...[
                          const SizedBox(width: 8),
                          _buildUrgentBadge("막차", Colors.red),
                        ] else if (lastStatus == 1) ...[
                          const SizedBox(width: 8),
                          _buildUrgentBadge("막차 전", Colors.orange),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),
                  Divider(height: 1, color: Colors.grey[200]),

                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 2, bottom: 8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.grey[100],
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey[300]!),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.directions_walk_rounded, size: 14, color: Colors.grey),
                                const SizedBox(width: 4),
                                Text("도보 약 ${walkMin}분 이동", style: TextStyle(color: Colors.grey[700], fontSize: 12, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ),

                        _buildRouteDetailRow("승차", route['startStation'], Colors.blueAccent),

                        Padding(
                          padding: const EdgeInsets.only(left: 7, top: 4, bottom: 4),
                          child: Row(
                            children: [
                              Container(width: 2, height: 20, color: Colors.grey[300]),
                              const SizedBox(width: 20),
                              Text(
                                  "(약 $stopCount개 정류장 이동)",
                                  style: TextStyle(color: Colors.grey[500], fontSize: 12, fontWeight: FontWeight.w500)
                              ),
                            ],
                          ),
                        ),

                        _buildRouteDetailRow("하차", route['endStation'], Colors.redAccent),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildUrgentBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildCongestionBadge(int? congestion) {
    String text;
    Color color;
    Color textColor = Colors.white;

    switch (congestion) {
      case 1: text = "여유"; color = Colors.green; break;
      case 2: text = "보통"; color = Colors.blue; break;
      case 3: text = "혼잡"; color = Colors.amber; textColor = Colors.black87; break;
      case 4: text = "매우 혼잡"; color = Colors.red; break;
      default: text = "정보 없음"; color = Colors.grey[400]!; break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8)
      ),
      child: Text(text, style: TextStyle(color: textColor, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildRouteDetailRow(String type, String station, Color color) {
    return Row(
      children: [
        Container(
            width: 16, height: 16,
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: color, width: 4), shape: BoxShape.circle)
        ),
        const SizedBox(width: 12),
        Text(type, style: TextStyle(color: Colors.grey[600], fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
              station,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black87),
              overflow: TextOverflow.ellipsis
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyView() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.search_off_rounded, size: 64, color: Colors.grey[300]), const SizedBox(height: 16), Text(_statusMessage, style: TextStyle(color: Colors.grey[500], fontSize: 16), textAlign: TextAlign.center)]));
  }
}
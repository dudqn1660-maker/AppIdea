import 'package:flutter/material.dart';
import 'package:bus/services/place_service.dart';
import 'package:bus/services/geolocation_service.dart'; // ⭐️ 여기만 있으면 됨
import 'package:bus/screens/route_result_screen.dart';

class DestinationSearchScreen extends StatefulWidget {
  const DestinationSearchScreen({Key? key}) : super(key: key);

  @override
  State<DestinationSearchScreen> createState() => _DestinationSearchScreenState();
}

class _DestinationSearchScreenState extends State<DestinationSearchScreen> {
  final TextEditingController _startController = TextEditingController();
  final TextEditingController _endController = TextEditingController();
  final FocusNode _startFocus = FocusNode();
  final FocusNode _endFocus = FocusNode();

  Place? _startPlace;
  Place? _endPlace;

  final PlaceService _placeService = PlaceService();
  final GeolocationService _geolocationService = GeolocationService();

  List<Place> _searchResults = [];
  bool _isLoading = false;
  bool _isSearchingStart = true;
  bool _isLocating = false;

  @override
  void initState() {
    super.initState();
    _startFocus.addListener(() { if (_startFocus.hasFocus) setState(() => _isSearchingStart = true); });
    _endFocus.addListener(() { if (_endFocus.hasFocus) setState(() => _isSearchingStart = false); });
  }

  @override
  void dispose() {
    _startController.dispose(); _endController.dispose();
    _startFocus.dispose(); _endFocus.dispose();
    super.dispose();
  }

  void _search() async {
    final query = _isSearchingStart ? _startController.text : _endController.text;
    if (query.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      final results = await _placeService.searchPlaces(query);
      setState(() => _searchResults = results);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('검색 실패')));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _onPlaceSelected(Place place) {
    setState(() {
      if (_isSearchingStart) {
        _startPlace = place;
        _startController.text = place.placeName;
        FocusScope.of(context).requestFocus(_endFocus);
      } else {
        _endPlace = place;
        _endController.text = place.placeName;
        FocusScope.of(context).unfocus();
      }
      _searchResults = [];
    });
  }

  // ⭐️ [수정됨] GeolocationService 사용 (Kakao API 활용)
  void _setCurrentLocationAsStart() async {
    setState(() {
      _isLocating = true;
      _searchResults = [];
    });

    FocusScope.of(context).unfocus();

    try {
      // GeolocationService를 통해 현재 위치를 'Place' 객체(건물명 포함)로 받아옴
      final currentPlace = await _geolocationService.getCurrentLocationAsPlace();

      // GPS 오류 등으로 좌표가 0인 경우 처리
      if (currentPlace.lat == 0.0) {
        throw Exception("위치를 가져오지 못했습니다.");
      }

      setState(() {
        _startPlace = currentPlace;
        _startController.text = currentPlace.placeName; // 예: "신구대학교"

        // 안내 메시지
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('출발지가 "${currentPlace.placeName}"로 설정되었습니다.')),
        );

        // 도착지 입력창으로 포커스 이동
        FocusScope.of(context).requestFocus(_endFocus);
      });

    } catch (e) {
      final errorMsg = e.toString().contains('거부')
          ? '위치 권한이 필요합니다. 설정에서 허용해주세요.'
          : '현재 위치를 가져올 수 없습니다. GPS를 확인해주세요.';

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMsg)),
      );
    } finally {
      setState(() {
        _isLocating = false;
      });
    }
  }

  void _navigateToRouteResult() {
    if (_startPlace == null || _endPlace == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('출발지와 도착지를 모두 설정해주세요.')));
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RouteResultScreen(
          startPlace: _startPlace!,
          endPlace: _endPlace!,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('경로 검색', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        centerTitle: true,
      ),
      body: Column(
        children: [
          _buildInputArea(),
          Expanded(
            child: _isLoading || _isLocating
                ? Center(child: _isLocating
                ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text('정확한 위치 확인 중...', style: TextStyle(color: Colors.grey[500])),
              ],
            )
                : const CircularProgressIndicator()
            )
                : _searchResults.isEmpty
                ? _buildEmptyState()
                : ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 16),
              itemCount: _searchResults.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final place = _searchResults[index];
                return _buildPlaceItem(place);
              },
            ),
          ),
          if (_startPlace != null && _endPlace != null)
            _buildBottomButton(),
        ],
      ),
    );
  }

  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 15, offset: Offset(0, 5)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              const SizedBox(height: 18),
              const Icon(Icons.circle, color: Colors.blueAccent, size: 10),
              Container(
                height: 45,
                width: 1,
                margin: const EdgeInsets.symmetric(vertical: 4),
                color: Colors.grey[300],
              ),
              const Icon(Icons.location_on, color: Colors.redAccent, size: 20),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              children: [
                _buildTextField(
                  controller: _startController,
                  focusNode: _startFocus,
                  hint: '출발지 검색 (예: 집)',
                  isStart: true,
                  leadingWidget: GestureDetector(
                    onTap: _setCurrentLocationAsStart,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.my_location, color: Colors.blueAccent, size: 20),
                          const SizedBox(width: 4),
                          const Text("내 위치", style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                _buildTextField(
                  controller: _endController,
                  focusNode: _endFocus,
                  hint: '도착지 검색 (예: 회사)',
                  isStart: false,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String hint,
    required bool isStart,
    Widget? leadingWidget,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onTap: () => setState(() => _isSearchingStart = isStart),
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, height: 1.2),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.normal),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          prefixIcon: leadingWidget,
          suffixIcon: IconButton(
            icon: const Icon(Icons.search, color: Colors.grey),
            onPressed: _search,
          ),
        ),
        onSubmitted: (_) => _search(),
      ),
    );
  }

  Widget _buildPlaceItem(Place place) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.blue[50],
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.place, color: Colors.blueAccent, size: 24),
        ),
        title: Text(
          place.placeName,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(place.address, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
        ),
        onTap: () => _onPlaceSelected(place),
      ),
    );
  }

  Widget _buildBottomButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
        child: ElevatedButton(
          onPressed: _navigateToRouteResult,
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 56),
            backgroundColor: const Color(0xFF3B5998),
            foregroundColor: Colors.white,
            elevation: 4,
            shadowColor: Colors.blueAccent.withOpacity(0.3),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.directions_bus_filled_rounded),
              SizedBox(width: 8),
              Text('경로 분석 및 버스 찾기', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isSearchingStart ? Icons.my_location_rounded : Icons.location_on_rounded,
            size: 60,
            color: Colors.grey[300],
          ),
          const SizedBox(height: 16),
          Text(
            _isSearchingStart ? '출발지를 검색해주세요.' : '도착지를 검색해주세요.',
            style: TextStyle(color: Colors.grey[400], fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
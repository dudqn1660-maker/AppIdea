import 'package:flutter/material.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/favorite_service.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';
// ⭐️ [NEW] 방금 만든 지도 화면 임포트
import 'package:bus/screens/station_map_screen.dart';

class SearchTab extends StatefulWidget {
  const SearchTab({Key? key}) : super(key: key);

  @override
  State<SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<SearchTab> {
  final BusApiService _apiService = BusApiService();
  final FavoriteService _favoriteService = FavoriteService();
  final TextEditingController _searchController = TextEditingController();

  List<BusStation> _searchResult = [];
  bool _isStationSearching = false;
  Map<String, bool> _favoriteStates = {};

  @override
  void initState() {
    super.initState();
    _refreshFavorites();
  }

  Future<void> _refreshFavorites() async {
    final favs = await _favoriteService.getFavorites();
    final newState = <String, bool>{};
    for (var station in _searchResult) {
      newState[station.stationId] = favs.any((f) => f.stationId == station.stationId);
    }
    if (mounted) setState(() => _favoriteStates = newState);
  }

  void _toggleFavorite(BusStation station) async {
    bool isFav = _favoriteStates[station.stationId] ?? false;
    if (isFav) {
      await _favoriteService.removeFavorite(station.stationId);
      _showSnackBar('${station.stationName} 즐겨찾기 해제');
    } else {
      await _favoriteService.addFavorite(station);
      _showSnackBar('${station.stationName} 즐겨찾기 추가');
    }
    _refreshFavorites();
  }

  void _searchStation() async {
    final stationName = _searchController.text;
    if (stationName.isEmpty) return;
    FocusScope.of(context).unfocus();

    setState(() {
      _isStationSearching = true;
      _searchResult = [];
    });

    try {
      final stations = await _apiService.searchStation(stationName);

      final uniqueStations = <String, BusStation>{};
      for (var station in stations) {
        uniqueStations[station.stationId] = station;
      }

      setState(() => _searchResult = uniqueStations.values.toList());
      _refreshFavorites();
    } catch (e) {
      _showSnackBar('검색 실패');
    } finally {
      setState(() => _isStationSearching = false);
    }
  }

  // ⭐️ [NEW] 지도 화면으로 이동하는 함수
  void _navigateToMap(BusStation station) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => StationMapScreen(station: station)),
    );
  }

  void _navigateToDetail(BusStation station) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: station)),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).removeCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), duration: const Duration(seconds: 1)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('정류소 검색', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        children: [
          _buildSearchInputArea(),
          Expanded(child: _buildResultArea()),
        ],
      ),
    );
  }

  Widget _buildSearchInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 15, offset: Offset(0, 5))],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(16)),
              child: TextField(
                controller: _searchController,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                decoration: const InputDecoration(
                  hintText: '정류소 이름 (예: 수원역)',
                  prefixIcon: Icon(Icons.search_rounded, color: Colors.grey),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                onSubmitted: (_) => _searchStation(),
              ),
            ),
          ),
          const SizedBox(width: 12),
          ElevatedButton(
            onPressed: _searchStation,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B5998),
              padding: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            child: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildResultArea() {
    if (_isStationSearching) return const Center(child: CircularProgressIndicator(color: Color(0xFF3B5998)));
    if (_searchResult.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.location_city_rounded, size: 80, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text('정류소를 검색해보세요', style: TextStyle(color: Colors.grey[500], fontSize: 16)),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 80),
      itemCount: _searchResult.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final station = _searchResult[index];
        final isFav = _favoriteStates[station.stationId] ?? false;
        return _buildStationCard(station, isFav);
      },
    );
  }

  Widget _buildStationCard(BusStation station, bool isFav) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),

        // 왼쪽 버스 아이콘
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: const Color(0xFFE3F2FD), borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.directions_bus_rounded, color: Color(0xFF3B5998), size: 24),
        ),

        // 가운데 (이름 + ID 뱃지)
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              station.stationName,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: Color(0xFF2D3436)),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                  child: Text(
                    'ID ${station.mobileNo ?? station.stationId}',
                    style: TextStyle(color: Colors.grey[600], fontSize: 11, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ],
        ),

        // 오른쪽 버튼들 (지도 + 즐겨찾기)
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // ⭐️ [NEW] 지도 버튼 추가
            IconButton(
              icon: const Icon(Icons.map_outlined, color: Colors.blueAccent),
              tooltip: '위치 확인',
              onPressed: () => _navigateToMap(station),
            ),
            // 즐겨찾기 버튼
            IconButton(
              icon: Icon(isFav ? Icons.star_rounded : Icons.star_border_rounded, color: isFav ? Colors.amber : Colors.grey, size: 30),
              tooltip: '즐겨찾기',
              onPressed: () => _toggleFavorite(station),
            ),
          ],
        ),

        onTap: () => _navigateToDetail(station),
      ),
    );
  }
}
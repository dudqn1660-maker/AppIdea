import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/favorite_service.dart'; // ⭐️ 추가
import 'package:bus/screens/destination_search_screen.dart';
import 'package:bus/services/navigation_state_service.dart';
import 'package:bus/screens/navigation_screen.dart';

class HomeTab extends StatefulWidget {
  final ValueChanged<int>? onTabChange;

  const HomeTab({Key? key, this.onTabChange}) : super(key: key);

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final BusApiService _apiService = BusApiService();
  final NavigationStateService _navService = NavigationStateService();

  // ⭐️ [추가] 실제 즐겨찾기 데이터를 가져오기 위한 서비스
  final FavoriteService _favoriteService = FavoriteService();

  late Future<List<BusStation>> _nearbyStationsFuture = Future.value([]);
  // ⭐️ [추가] 즐겨찾기 목록 Future
  late Future<List<BusStation>> _favoriteStationsFuture;

  @override
  void initState() {
    super.initState();
    _loadData(); // 데이터 로드 통합
    _navService.addListener(_onNavStateChanged);
  }

  @override
  void dispose() {
    _navService.removeListener(_onNavStateChanged);
    super.dispose();
  }

  void _onNavStateChanged() {
    if (mounted) setState(() {});
  }

  void _loadData() {
    _loadNearbyStations();
    // ⭐️ 즐겨찾기 목록 로드
    _favoriteStationsFuture = _favoriteService.getFavorites();
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return Future.error('위치 서비스를 활성화해주세요.');

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return Future.error('위치 권한이 거부되었습니다.');
    }

    if (permission == LocationPermission.deniedForever) return Future.error('위치 권한을 영구적으로 허용해주세요.');

    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
  }

  Future<List<BusStation>> _getNearbyStationsFuture() async {
    try {
      final Position position = await _determinePosition();
      return await _apiService.searchNearbyStations(position.latitude, position.longitude, 500);
    } catch (e) {
      throw Exception('위치 정보 로딩 실패');
    }
  }

  void _loadNearbyStations() {
    setState(() {
      _nearbyStationsFuture = _getNearbyStationsFuture();
    });
  }

  void _refreshAllData() {
    setState(() {
      _loadData(); // 즐겨찾기 및 주변 정류장 모두 새로고침
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('새로고침 완료!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.directions_bus_filled_rounded, color: Color(0xFF3B5998)),
            SizedBox(width: 8),
            Text('경기버스 알리미', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF2D3436))),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
            onPressed: _refreshAllData,
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded, color: Colors.black87),
            onPressed: () {},
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildSearchBar(),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("빠른 실행", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
                        const SizedBox(height: 12),

                        _navService.isNavigating
                            ? _buildActiveNavigationCard()
                            : _buildQuickActions(),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  _buildSectionHeader('즐겨찾는 정류장', Icons.star_rounded, Colors.amber, 3),
                  _buildFavoriteStations(), // ⭐️ 메서드 이름 변경 및 실제 데이터 연결

                  const SizedBox(height: 24),

                  _buildSectionHeader('내 주변 정류장', Icons.near_me_rounded, Colors.blueAccent, 2),
                  _buildNearbyStations(),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActiveNavigationCard() {
    final bus = _navService.currentBus;
    final startStation = _navService.startStation;
    final endStation = _navService.endStation;

    if (bus == null) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NavigationScreen(
              bus: bus,
              startStation: startStation ?? "출발지",
              endStation: endStation ?? "도착지",
            ),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF3B5998),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: const Color(0xFF3B5998).withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
              child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${bus.routeName}번 타고 이동 중", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text("목적지: ${endStation ?? '-'}", style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: GestureDetector(
        onTap: () => widget.onTabChange!(1),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFF0F2F5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Row(
            children: [
              const Icon(Icons.search_rounded, color: Colors.grey),
              const SizedBox(width: 12),
              Text('정류장 검색', style: TextStyle(color: Colors.grey[500], fontSize: 15, fontWeight: FontWeight.w500)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color iconColor, int tabIndex) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
            ],
          ),
          GestureDetector(
            onTap: () => widget.onTabChange!(tabIndex),
            child: const Text('더보기', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  // ⭐️ [핵심 수정] 실제 즐겨찾기 목록을 불러와서 표시
  Widget _buildFavoriteStations() {
    return FutureBuilder<List<BusStation>>(
      future: _favoriteStationsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
        }

        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 30),
            child: Column(
              children: [
                Icon(Icons.star_border_rounded, size: 40, color: Colors.grey[300]),
                const SizedBox(height: 10),
                Text("즐겨찾는 정류장이 없습니다.", style: TextStyle(color: Colors.grey[400])),
              ],
            ),
          );
        }

        final favorites = snapshot.data!;
        // 최대 3개까지만 홈 화면에 표시
        final displayList = favorites.take(3).toList();

        return Column(
          children: displayList.map((station) {
            // 각 정류장의 도착 정보 조회
            return FutureBuilder<List<BusArrivalInfo>>(
              future: _apiService.fetchBusArrival(station.stationId),
              builder: (context, arrivalSnapshot) {
                String infoText = "도착 정보 조회 중...";
                Color infoColor = Colors.grey;
                String firstBusName = "";

                if (arrivalSnapshot.hasData && arrivalSnapshot.data!.isNotEmpty) {
                  // 가장 빨리 오는 버스 1개 찾기
                  final sortedArrivals = arrivalSnapshot.data!..sort((a, b) => (a.predictTime ?? 999).compareTo(b.predictTime ?? 999));
                  final firstBus = sortedArrivals.first;

                  firstBusName = firstBus.routeName ?? "";
                  final time = firstBus.predictTime;

                  if (time != null) {
                    if (time == 0) {
                      infoText = "곧 도착";
                      infoColor = Colors.redAccent;
                    } else {
                      infoText = "$time분 후";
                      infoColor = time <= 5 ? Colors.redAccent : const Color(0xFF3B5998);
                    }
                  } else {
                    infoText = firstBus.arrivalInfo ?? "정보 없음";
                  }
                } else if (arrivalSnapshot.hasData && arrivalSnapshot.data!.isEmpty) {
                  infoText = "도착 예정 없음";
                } else if (arrivalSnapshot.hasError) {
                  infoText = "정보 오류";
                }

                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) => BusArrivalDetailScreen(station: station),
                      ));
                    },
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.amber.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.star_rounded, color: Colors.amber, size: 24),
                    ),
                    title: Text(
                        station.stationName,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis
                    ),
                    subtitle: firstBusName.isNotEmpty
                        ? Text("$firstBusName번 $infoText", style: TextStyle(color: infoColor, fontWeight: FontWeight.w600))
                        : Text(infoText, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.grey),
                  ),
                );
              },
            );
          }).toList(),
        );
      },
    );
  }

  Widget _buildNearbyStations() {
    return SizedBox(
      height: 160,
      child: FutureBuilder<List<BusStation>>(
        future: _nearbyStationsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("주변에 정류장이 없습니다.", style: TextStyle(color: Colors.grey[400])));
          }

          return ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: snapshot.data!.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final station = snapshot.data![index];
              return Container(
                width: 140,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: station)));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blueAccent.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.location_on, color: Colors.blueAccent, size: 20),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(station.stationName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 4),
                              Text("${station.mobileNo ?? '-'}", style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildQuickActions() {
    return ElevatedButton(
      onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => const DestinationSearchScreen()));
      },
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(double.infinity, 80),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF3B5998),
        elevation: 2,
        shadowColor: Colors.black12,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding: EdgeInsets.zero,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF3B5998).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.map_rounded, color: Color(0xFF3B5998), size: 32),
            ),
            const SizedBox(width: 20),
            const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("길찾기 / 경로 검색", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87)),
                SizedBox(height: 4),
                Text("목적지까지 가장 빠른 버스 찾기", style: TextStyle(fontSize: 13, color: Colors.grey)),
              ],
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.grey, size: 16),
          ],
        ),
      ),
    );
  }
}
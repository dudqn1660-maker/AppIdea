import 'package:flutter/material.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/favorite_service.dart';
import 'package:bus/services/route_favorite_service.dart';
import 'package:bus/widgets/favorite_station_card.dart';
import 'package:bus/screens/route_result_screen.dart';

class FavoriteTab extends StatefulWidget {
  const FavoriteTab({Key? key}) : super(key: key);

  @override
  State<FavoriteTab> createState() => _FavoriteTabState();
}

class _FavoriteTabState extends State<FavoriteTab> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final FavoriteService _stationService = FavoriteService();
  final RouteFavoriteService _routeService = RouteFavoriteService();

  String? _selectedRouteId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    _tabController.addListener(() {
      if (_tabController.indexIsChanging) {
        setState(() {
          _selectedRouteId = null;
        });
      }
    });
  }

  // ⭐️ 삭제 확인 창 디자인 통일 (삭제 버튼은 빨간색 Elevated Button)
  void _showDeleteDialog(VoidCallback onConfirm) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text("삭제 확인", style: TextStyle(fontWeight: FontWeight.bold)),
        content: const Text("이 항목을 즐겨찾기에서 삭제하시겠습니까?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("취소", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              onConfirm();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent, // 파괴적 액션 색상
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              elevation: 4,
            ),
            child: const Text("삭제", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('즐겨찾기', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF3B5998),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF3B5998),
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          tabs: const [
            Tab(text: "정류소"),
            Tab(text: "자주 가는 경로"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildStationList(),
          _buildRouteList(), // 경로 탭
        ],
      ),
    );
  }

  // ⭐️ [주의] FavoriteStationCard 내의 아이콘을 수정해야 합니다.
  Widget _buildStationList() {
    return FutureBuilder<List<BusStation>>(
      future: _stationService.getFavorites(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFF3B5998)));
        final list = snapshot.data!;
        if (list.isEmpty) return _buildEmptyState("즐겨찾는 정류소가 없어요", Icons.bookmark_border_rounded);

        /* ⚠️ 중요: 정류소 카드 아이콘 통일 ⚠️
        FavoriteStationCard.dart 파일 내부의 삭제 버튼 아이콘을
        Icons.delete_outline_rounded (휴지통 아이콘)으로 변경해주세요.
        */

        return ListView.separated(
          padding: const EdgeInsets.all(20),
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(height: 16),
          itemBuilder: (context, index) {
            return FavoriteStationCard(
              station: list[index],
              onRemove: () {
                _showDeleteDialog(() async {
                  await _stationService.removeFavorite(list[index].stationId);
                  setState(() {});
                });
              },
            );
          },
        );
      },
    );
  }

  // ⭐️ [수정] 경로 리스트 + 하단 버튼 (부자연스러움 해결)
  Widget _buildRouteList() {
    return FutureBuilder<List<FavoriteRoute>>(
      future: _routeService.getRoutes(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator(color: Color(0xFF3B5998)));
        final list = snapshot.data!;
        if (list.isEmpty) return _buildEmptyState("저장된 경로가 없어요", Icons.map_outlined);

        FavoriteRoute? selectedRoute;
        try {
          selectedRoute = list.firstWhere((r) => r.id == _selectedRouteId);
        } catch (e) {
          _selectedRouteId = null;
        }

        final bool isRouteSelected = selectedRoute != null;

        return Stack(
          children: [
            // 1. 리스트 뷰
            ListView.separated(
              // ⭐️ [수정] 하단 버튼이 항상 보이므로 bottom padding을 100으로 고정하여 리스트 점프 현상 해결
              padding: const EdgeInsets.only(top: 20, left: 20, right: 20, bottom: 100),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                final route = list[index];
                final isSelected = route.id == _selectedRouteId;

                return Container(
                  decoration: BoxDecoration(
                    color: isSelected ? const Color(0xFFE8F0FE) : Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: isSelected ? Border.all(color: const Color(0xFF3B5998), width: 2) : null,
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        setState(() {
                          if (_selectedRouteId == route.id) {
                            _selectedRouteId = null; // 선택 해제
                          } else {
                            _selectedRouteId = route.id;
                          }
                        });
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Row(
                          children: [
                            Column(
                              children: [
                                Icon(Icons.circle, size: 10, color: isSelected ? const Color(0xFF3B5998) : Colors.blueAccent),
                                Container(width: 2, height: 20, color: Colors.grey[300], margin: const EdgeInsets.symmetric(vertical: 2)),
                                const Icon(Icons.location_on, size: 18, color: Colors.redAccent),
                              ],
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(route.name, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: isSelected ? const Color(0xFF3B5998) : const Color(0xFF2D3436))),
                                  const SizedBox(height: 6),
                                  Text(route.start.placeName, style: const TextStyle(fontSize: 14, color: Colors.black87)),
                                  const SizedBox(height: 4),
                                  Text(route.end.placeName, style: const TextStyle(fontSize: 14, color: Colors.black87)),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete_outline_rounded, color: isSelected ? const Color(0xFF3B5998) : Colors.grey),
                              onPressed: () {
                                _showDeleteDialog(() async {
                                  await _routeService.removeRoute(route.id);
                                  setState(() {
                                    if (_selectedRouteId == route.id) {
                                      _selectedRouteId = null;
                                    }
                                  });
                                });
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

            // 2. 하단 고정 안내 시작 버튼 (항상 표시, 활성화/비활성화 상태 제어)
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -4))],
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: SafeArea(
                  child: ElevatedButton(
                    // ⭐️ [수정] 선택되었을 때만 onPressed 활성화 (비활성화 시 색상 변경으로 부자연스러움 해소)
                    onPressed: isRouteSelected ? () {
                      Navigator.push(context, MaterialPageRoute(
                        builder: (context) => RouteResultScreen(
                          startPlace: selectedRoute!.start,
                          endPlace: selectedRoute!.end,
                        ),
                      ));
                    } : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isRouteSelected ? const Color(0xFF3B5998) : Colors.grey,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 56),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      elevation: isRouteSelected ? 4 : 0,
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.navigation_rounded, size: 24),
                        SizedBox(width: 10),
                        Text("안내 시작", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildEmptyState(String msg, IconData icon) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 60, color: Colors.grey[300]),
          const SizedBox(height: 16),
          Text(msg, style: TextStyle(color: Colors.grey[400], fontSize: 16)),
        ],
      ),
    );
  }
}
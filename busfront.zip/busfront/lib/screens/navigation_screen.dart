import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart'; // flutter_map 패키지
import 'package:latlong2/latlong.dart';        // latlong2 패키지
import 'package:geolocator/geolocator.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/models/bus_location.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/notification_service.dart';
import 'package:bus/services/navigation_state_service.dart';

class NavigationScreen extends StatefulWidget {
  final BusArrivalInfo bus;
  final String startStation;
  final String endStation;

  const NavigationScreen({
    Key? key,
    required this.bus,
    required this.startStation,
    required this.endStation,
  }) : super(key: key);

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  final BusApiService _apiService = BusApiService();
  final MapController _mapController = MapController();
  final NavigationStateService _navService = NavigationStateService();

  Timer? _arrivalTimer;
  StreamSubscription<Position>? _positionStream;

  List<BusRouteStop> _fullRouteStops = [];
  List<LatLng> _busRoutePoints = [];

  Position? _currentPosition;
  BusRouteStop? _startNode;
  BusRouteStop? _endNode;

  LatLng? _realtimeBusPosition;
  String? _targetPlateNo;

  // 상태 변수
  bool _isBoarded = false;
  bool _hasAskedAboutBoarding = false;

  int? _stopsToPickup;
  int _stopsToDropoff = 999;
  String _timeToPickup = "조회중...";

  bool _hasPickupAlerted = false;
  bool _hasDropoffAlerted = false;

  // 버스가 지나갔는지 체크하는 플래그
  bool _isBusPassed = false;

  final Color _primaryColor = const Color(0xFF3B5998);

  @override
  void initState() {
    super.initState();
    _initNavigation();

    // 화면이 그려진 후, 전역 상태 서비스와 동기화
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // 이미 안내 중인 버스와 동일한 버스라면 상태 복구
      if (_navService.isNavigating && _navService.currentBus?.routeId == widget.bus.routeId) {
        setState(() {
          _isBoarded = _navService.isBoarded;
          // 이미 탑승 상태라면 탑승 질문을 다시 하지 않음
          if (_isBoarded) {
            _hasAskedAboutBoarding = true;
          }
        });
      } else {
        // ⭐️ [수정됨] 새로운 안내 시작 시 startStation도 함께 전달
        _navService.startNavigation(widget.bus, widget.startStation, widget.endStation);
      }
    });
  }

  @override
  void dispose() {
    _arrivalTimer?.cancel();
    _positionStream?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  // ⭐️ 뒤로가기 버튼: 안내 종료 없이 화면만 닫음 (홈 화면 카드 유지)
  void _onBackPress() {
    Navigator.pop(context);
  }

  // 안내 종료 버튼 (이건 진짜 종료)
  void _confirmCancelNavigation() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text("안내 종료 확인", style: TextStyle(fontWeight: FontWeight.bold)),
          content: const Text("버스 안내를 정말 종료하시겠습니까?", style: TextStyle(fontSize: 15)),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("취소", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () {
                Navigator.pop(context);
                _navService.stopNavigation(); // 전역 상태 초기화
                Navigator.pop(context); // 화면 닫기
              },
              child: const Text("안내 종료", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  void _showBoardingConfirmationDialog() {
    if (!mounted) return;

    NotificationService.showNotification(
      title: "버스 도착!",
      body: "${widget.bus.routeName}번 버스가 도착했습니다. 탑승하셨나요?",
    );

    showDialog<String>(
      context: context,
      barrierDismissible: false, // 바깥 터치로 닫기 금지
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text("탑승 확인", style: TextStyle(fontWeight: FontWeight.bold)),
          content: Text("${widget.bus.routeName}번 버스가 도착했습니다.\n탑승하셨나요?", style: const TextStyle(fontSize: 15)),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop('missed'),
              child: const Text("놓쳤어요", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop('boarded'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("탑승했어요", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    ).then((action) async {
      if (!mounted) return;
      if (action == 'boarded') {
        setState(() {
          _isBoarded = true;
        });
        _navService.setBoarded(true); // 전역 상태 업데이트

        _showAlertDialog(title: "탑승 확인", content: "탑승이 확인되었습니다. 목적지까지 안내합니다!", color: Colors.blueAccent);
      } else if (action == 'missed') {
        _navService.stopNavigation();
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('안내를 종료합니다.')));
      }
    });
  }

  String _normalizeName(String name) {
    return name.replaceAll(' ', '').replaceAll('.', '').replaceAll('(', '').replaceAll(')', '').trim();
  }

  Future<void> _showAlertDialog({required String title, required String content, required Color color}) async {
    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Icon(Icons.notifications_active_rounded, color: color),
              const SizedBox(width: 10),
              Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20)),
            ],
          ),
          content: Text(content, style: const TextStyle(fontSize: 16)),
          actions: [
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("확인", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _initNavigation() async {
    if (widget.bus.routeId == null) return;

    try {
      final stops = await _apiService.getBusRoute(widget.bus.routeId!);

      String startName = _normalizeName(widget.startStation);
      String endName = _normalizeName(widget.endStation);

      int startIndex = -1;
      int endIndex = -1;
      int minDistance = 99999;

      // 1. 모든 정류장을 순회하며 가능한 출발-도착 쌍을 모두 검사
      for (int i = 0; i < stops.length; i++) {
        if (_normalizeName(stops[i].stationName).contains(startName)) {
          for (int j = i + 1; j < stops.length; j++) {
            if (_normalizeName(stops[j].stationName).contains(endName)) {
              int distance = j - i;
              if (distance < minDistance) {
                minDistance = distance;
                startIndex = i;
                endIndex = j;
              }
              if (minDistance < 3) break;
            }
          }
        }
      }

      // 못 찾았을 경우 대비 (기존 로직 fallback)
      if (startIndex == -1 || endIndex == -1) {
        startIndex = stops.indexWhere((s) => _normalizeName(s.stationName).contains(startName));
        endIndex = stops.indexWhere((s) => _normalizeName(s.stationName).contains(endName));

        if (startIndex == -1) startIndex = 0;
        if (endIndex == -1) endIndex = stops.length - 1;

        if (startIndex > endIndex) {
          int temp = startIndex; startIndex = endIndex; endIndex = temp;
        }
      }

      // 경로 그리기용 포인트 추출
      final routeSegment = stops.sublist(startIndex, endIndex + 1);
      final points = routeSegment
          .where((s) => s.latitude != 0.0 && s.longitude != 0.0)
          .map((s) => LatLng(s.latitude, s.longitude))
          .toList();

      if (mounted) {
        setState(() {
          _fullRouteStops = stops;
          _startNode = stops[startIndex];
          _endNode = stops[endIndex];
          _busRoutePoints = points;
        });
      }

      _startLocationTracking();
      _updateBusInfo();

      // 10초마다 버스 위치/도착 정보 갱신
      _arrivalTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
        _updateBusInfo();
      });

    } catch (e) {
      print("초기화 에러: $e");
    }
  }

  Future<void> _updateBusInfo() async {
    if (_startNode == null || widget.bus.routeId == null) return;

    try {
      // 1. 실시간 버스 위치 목록 가져오기
      final locations = await _apiService.getBusLocations(widget.bus.routeId!);

      // 2. 내가 타려는 버스(차량번호) 찾기
      BusLocation? myBusLoc;
      if (_targetPlateNo != null) {
        String targetNum = _targetPlateNo!.replaceAll(RegExp(r'[^0-9]'), '');
        // 차량 번호 뒤 4자리 매칭
        if (targetNum.length > 4) targetNum = targetNum.substring(targetNum.length - 4);

        try {
          myBusLoc = locations.firstWhere(
                  (loc) => loc.plateNo.replaceAll(RegExp(r'[^0-9]'), '').endsWith(targetNum)
          );
        } catch (_) {}
      }

      // 3. 버스가 내 정류장을 지났는지 판별
      bool hasPassed = false;
      if (myBusLoc != null && _fullRouteStops.isNotEmpty) {
        int busCurrentIndex = _fullRouteStops.indexWhere((s) => s.stationId == myBusLoc!.stationId);
        int myStartIndex = _fullRouteStops.indexOf(_startNode!);

        if (busCurrentIndex > myStartIndex) {
          hasPassed = true;
        }

        // 지도상 마커 업데이트
        double lat = myBusLoc.latitude;
        double lng = myBusLoc.longitude;

        if (lat == 0.0 || lng == 0.0) {
          try {
            final currentStation = _fullRouteStops.firstWhere((s) => s.stationId == myBusLoc!.stationId);
            lat = currentStation.latitude;
            lng = currentStation.longitude;
          } catch (_) {}
        }

        if (mounted && lat != 0.0) {
          setState(() => _realtimeBusPosition = LatLng(lat, lng));
        }
      }

      // 4. 도착 정보 갱신 (탑승 전)
      if (!_isBoarded) {
        if (hasPassed) {
          if (mounted) {
            setState(() {
              _isBusPassed = true;
              _stopsToPickup = null;
              _timeToPickup = "이미 떠남";
            });
          }
          return;
        } else {
          if (mounted) setState(() => _isBusPassed = false);
        }

        final arrivals = await _apiService.fetchBusArrival(_startNode!.stationId);
        final myBus = arrivals.firstWhere(
              (b) => b.routeId == widget.bus.routeId,
          orElse: () => BusArrivalInfo(routeId: 'none'),
        );

        if (myBus.routeId != 'none') {
          if (_targetPlateNo == null && myBus.plateNo != null) {
            _targetPlateNo = myBus.plateNo;
          }

          int? stops = myBus.locationNo1 ?? myBus.remainingStops;
          int? minutes = myBus.predictTime1 ?? myBus.predictTime;

          if (stops == null && myBus.arrivalInfo != null) {
            final RegExp regExp = RegExp(r'(\d+)번째');
            final match = regExp.firstMatch(myBus.arrivalInfo!);
            if (match != null) stops = int.tryParse(match.group(1)!);
          }
          if (stops == null && minutes != null) {
            stops = (minutes / 2).ceil();
            if (stops < 1) stops = 1;
          }

          if (mounted) {
            setState(() {
              _stopsToPickup = stops;
              _timeToPickup = minutes != null ? "${minutes}분" : (myBus.arrivalInfo ?? "--");
            });
          }

          // ⭐️ [탑승 알림 조건 완화]
          bool isArriving = false;

          // (1) 텍스트 조건
          if (myBus.arrivalInfo != null) {
            String info = myBus.arrivalInfo!;
            if (info.contains('도착') || info.contains('진입') || info.contains('곧')) {
              isArriving = true;
            }
          }
          // (2) 시간 조건: 2분 이하
          if (minutes != null && minutes <= 2) {
            isArriving = true;
          }
          // (3) 정거장 조건: 1개 이하
          if (stops != null && stops <= 1) {
            isArriving = true;
          }

          if (!_hasAskedAboutBoarding && isArriving) {
            _hasAskedAboutBoarding = true;
            _showBoardingConfirmationDialog();
          }

          // 3정거장 전 알림
          if (stops != null && stops > 1 && stops <= 3 && !_hasPickupAlerted) {
            _hasPickupAlerted = true;
            NotificationService.showNotification(
              title: "버스 도착 임박!",
              body: "${widget.bus.routeName}번 버스가 $stops정거장 전입니다. 승차 준비를 해주세요!",
            );
          }
        }
      } else {
        // 탑승 후에는 버스 마커 제거
        if (mounted) setState(() => _realtimeBusPosition = null);
      }

    } catch (e) {
      print("갱신 오류: $e");
    }
  }

  void _startLocationTracking() {
    const locationSettings = LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5);

    _positionStream = Geolocator.getPositionStream(locationSettings: locationSettings)
        .listen((Position position) {
      if (!mounted) return;

      setState(() => _currentPosition = position);
      _mapController.move(LatLng(position.latitude, position.longitude), 16.5);
      _checkStatus(position);
    });
  }

  void _checkStatus(Position userPos) {
    if (_startNode == null || _fullRouteStops.isEmpty) return;

    int closestIndex = 0;
    double minDistance = double.infinity;

    for (int i = 0; i < _fullRouteStops.length; i++) {
      final stop = _fullRouteStops[i];
      if (stop.latitude == 0.0) continue;

      final dist = Geolocator.distanceBetween(userPos.latitude, userPos.longitude, stop.latitude, stop.longitude);
      if (dist < minDistance) {
        minDistance = dist;
        closestIndex = i;
      }
    }

    int endIndex = _fullRouteStops.indexOf(_endNode!);
    int stopsLeft = endIndex - closestIndex;
    if (stopsLeft < 0) stopsLeft = 0;

    if (mounted) {
      setState(() {
        _stopsToDropoff = stopsLeft;
      });
    }

    if (_isBoarded && !_hasDropoffAlerted) {
      if (_stopsToDropoff <= 2 && _stopsToDropoff > 0) {
        _hasDropoffAlerted = true;
        NotificationService.showNotification(
          title: "하차 준비!",
          body: "${_stopsToDropoff}정거장 후에 목적지(${widget.endStation})입니다. 하차 벨을 눌러주세요!",
        );
        _showAlertDialog(
            title: "하차 준비!",
            content: "${_stopsToDropoff}정거장 후에 목적지(${widget.endStation})입니다.\n하차 벨을 눌러주세요!",
            color: Colors.redAccent
        );
      } else if (_stopsToDropoff == 0) {
        _hasDropoffAlerted = true;
        _showAlertDialog(
            title: "도착 완료",
            content: "목적지에 도착했습니다. 짐 챙겨서 하차하세요!",
            color: Colors.blueAccent
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    String topStatus;
    Color topColor;

    if (_isBoarded) {
      topStatus = "목적지로 이동 중";
      topColor = const Color(0xFF43A047);
    } else if (_isBusPassed) {
      topStatus = "버스가 지나갔습니다";
      topColor = Colors.redAccent;
    } else {
      topStatus = "승차 정류장 대기 중";
      topColor = Colors.orange;
    }

    String bigNumber;
    String descText;

    if (_isBoarded) {
      bigNumber = "$_stopsToDropoff";
      descText = "목적지까지 남은 정거장";
    } else if (_isBusPassed) {
      bigNumber = "Miss";
      descText = "버스를 놓쳤을 수 있습니다.";
    } else {
      bigNumber = _stopsToPickup == null ? "?" : "$_stopsToPickup";
      descText = "버스가 오기까지 남은 정거장";
    }

    final double bottomPadding = MediaQuery.of(context).padding.bottom + 20;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: Colors.black87),
          ),
          onPressed: _onBackPress, // ⭐️ 수정됨: 안내 종료 없이 pop
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: topColor,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(color: topColor.withOpacity(0.4), blurRadius: 8)],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                  _isBoarded ? Icons.directions_bus_filled : Icons.accessibility_new_rounded,
                  color: Colors.white, size: 18
              ),
              const SizedBox(width: 8),
              Text(
                topStatus,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _currentPosition != null
                  ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude)
                  : const LatLng(37.5665, 126.9780),
              initialZoom: 16.0,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.bus_nav',
              ),
              PolylineLayer(
                polylines: [
                  if (_busRoutePoints.isNotEmpty)
                    Polyline(
                      points: _busRoutePoints,
                      strokeWidth: 6.0,
                      color: _primaryColor.withOpacity(0.7),
                      strokeCap: StrokeCap.round,
                    ),
                ],
              ),
              MarkerLayer(
                markers: [
                  if (_startNode != null)
                    Marker(
                      point: LatLng(_startNode!.latitude, _startNode!.longitude),
                      width: 50, height: 50,
                      child: _buildMarkerIcon(Icons.login_rounded, Colors.blue),
                    ),
                  if (_endNode != null)
                    Marker(
                      point: LatLng(_endNode!.latitude, _endNode!.longitude),
                      width: 60, height: 60,
                      child: _buildDestinationMarker(),
                    ),

                  if (!_isBoarded && _realtimeBusPosition != null)
                    Marker(
                      point: _realtimeBusPosition!,
                      width: 70, height: 70,
                      child: _buildBusMarker(),
                    ),

                  if (_currentPosition != null)
                    Marker(
                      point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
                      width: 70, height: 70,
                      child: _isBoarded ? _buildBusMarker(isMe: true) : _buildUserMarker(),
                    ),
                ],
              ),
            ],
          ),

          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, bottomPadding),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 25, offset: const Offset(0, -5)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("${widget.bus.routeName}번", style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF2D3436))),
                          const SizedBox(height: 4),
                          Text(
                            _isBoarded ? "To. ${widget.endStation}" : "From. ${widget.startStation}",
                            style: TextStyle(fontSize: 14, color: Colors.grey[600], fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _primaryColor.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isBoarded ? Icons.directions_bus_rounded : Icons.watch_later_rounded,
                          color: _primaryColor,
                          size: 24,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F7FA),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(descText, style: TextStyle(fontSize: 15, color: Colors.grey[600], fontWeight: FontWeight.w600)),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            Text(
                              bigNumber,
                              style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: _isBusPassed ? Colors.redAccent : _primaryColor),
                            ),
                            if (!_isBusPassed)
                              const SizedBox(width: 4),
                            if (!_isBusPassed)
                              const Text("정거장", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black54)),
                          ],
                        ),
                      ],
                    ),
                  ),

                  if (!_isBoarded)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Icon(Icons.timer_rounded, size: 14, color: Colors.grey),
                          const SizedBox(width: 4),
                          Text("상태: $_timeToPickup", style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: _isBusPassed ? Colors.red : Colors.grey)),
                        ],
                      ),
                    ),

                  Padding(
                    padding: EdgeInsets.only(top: _isBoarded ? 20 : 12),
                    child: ElevatedButton.icon(
                      onPressed: _confirmCancelNavigation,
                      icon: const Icon(Icons.cancel_rounded, size: 24),
                      label: const Text("안내 종료", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(double.infinity, 56),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- 마커 빌더 함수들 ---

  Widget _buildMarkerIcon(IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 4))],
      ),
      child: Icon(icon, color: color, size: 32),
    );
  }

  Widget _buildDestinationMarker() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(color: Colors.redAccent.withOpacity(0.2), shape: BoxShape.circle),
        ),
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: Colors.white, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6)],
          ),
          child: const Icon(Icons.flag_rounded, color: Colors.redAccent, size: 28),
        ),
      ],
    );
  }

  Widget _buildBusMarker({bool isMe = false}) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(
            color: (isMe ? _primaryColor : Colors.deepOrange).withOpacity(0.2),
            shape: BoxShape.circle,
          ),
        ),
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: isMe ? _primaryColor : Colors.deepOrange,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2.5),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6)],
          ),
          child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 22),
        ),
      ],
    );
  }

  Widget _buildUserMarker() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(color: _primaryColor.withOpacity(0.15), shape: BoxShape.circle),
        ),
        Container(
          width: 20, height: 20,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: _primaryColor, width: 3),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 4)],
          ),
        ),
      ],
    );
  }
}
package kr.ac.shingu.appfrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootthymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}

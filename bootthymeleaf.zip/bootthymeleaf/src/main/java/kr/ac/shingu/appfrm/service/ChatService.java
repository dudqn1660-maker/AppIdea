package kr.ac.shingu.appfrm.service;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import kr.ac.shingu.appfrm.mapper.ChatMapper;
import kr.ac.shingu.appfrm.repository.ChatMsg;
import kr.ac.shingu.appfrm.repository.ChatMsgRepository;
import net.minidev.json.JSONObject;

@Service
public class ChatService {
	
	private final Logger log = LoggerFactory.getLogger(ChatService.class);
	
    // 웹소켓 사용자 세션 관리
    private final Map<String, WebSocketSession> users = new ConcurrentHashMap<>();
    private final ChatMsgRepository chatMsgRepository;
    private final ChatMapper chatMapper;
    
    // 의존성 주입 (Dependency Injection)
    public ChatService(ChatMsgRepository chatMsgRepository, ChatMapper chatMapper) {
        this.chatMsgRepository = chatMsgRepository;
        this.chatMapper = chatMapper;
    }
	
	public void addUser(String nickname, WebSocketSession session) {
	    this.log.debug("New Chat User Nick: " + nickname);
	    this.users.put(nickname, session);
	    this.addMessage(nickname, "입장하였습니다.");
	}

	public void removeUser(String nickname) {
	    this.users.remove(nickname);
	    this.addMessage(nickname, "방을 나갔습니다.");
	}
	
	public void addMessage(String nickname, String msg) {
		// 1. 메시지 객체 생성 및 DB 저장
		ChatMsg chatMsg = new ChatMsg();
		chatMsg.setNickname(nickname);
		chatMsg.setChatContent(msg);
		chatMsg.setChatCreTime(new Date());
		//this.chatMsgRepository.save(chatMsg); // DB 저장
		long msgId = this.chatMapper.selectNextMsgId();
		chatMsg.setMsgId(msgId);
		this.chatMapper.insertChatMsg(chatMsg);	
		// 2. 웹소켓 메시지 포맷팅
	    JSONObject obj = new JSONObject();
	    obj.put("cmd", "msg");
	    obj.put("nickname", nickname);
	    obj.put("msg", msg);

	    TextMessage message = new TextMessage(obj.toJSONString());
	    
	    // 3. 현재 접속된 모든 사용자에게 메시지 전파
	    Set<Entry<String, WebSocketSession>> entrySet = this.users.entrySet();
	    for (Entry<String, WebSocketSession> entry : entrySet) {
	        WebSocketSession session = entry.getValue();
	        try {
	            session.sendMessage(message);
	            this.log.debug(entry.getKey() + " added");
	        } catch (IOException e) {
	            e.printStackTrace();
			}
		}
	}	
	
	
	public String loadAllChatMsg() {
	    // 1. DB에서 채팅 생성 시간(chatCreTime) 순으로 전체 메시지 조회
	    //Iterable<ChatMsg> msgList = this.chatMsgRepository.findAll(
         //   Sort.by(Direction.ASC, "chatCreTime")
	    //);
		List<ChatMsg> msgList = this.chatMapper.selectAllChatMsg("order by chat_cre_time asc");

	    StringBuilder msg = new StringBuilder();

	    // 2. 메시지 포맷팅: [닉네임] 채팅 내용\n
	    for (ChatMsg chatMsg : msgList) {
	        msg.append("[")
	           .append(chatMsg.getNickname())
	           .append("] ")
	           .append(chatMsg.getChatContent())
	           .append("\n");
	    }

	    // 3. 마지막 줄 바꿈 문자 제거 후 반환
	    return msg.toString().trim();
	}
	
	// 주석 처리된 이전 코드 부분
	/*
	public BlockingQueue<String> addUser(String nick) {
		BlockingQueue<String> queue = new ArrayBlockingQueue<>(100);
		this.users.put(nick, queue);
		return queue;
	}
	*/
}
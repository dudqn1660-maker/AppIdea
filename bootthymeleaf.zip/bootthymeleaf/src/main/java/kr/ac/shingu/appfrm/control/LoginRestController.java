package kr.ac.shingu.appfrm.control;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import kr.ac.shingu.appfrm.data.LoginData;
import kr.ac.shingu.appfrm.data.ResponseData;
import kr.ac.shingu.appfrm.mapper.ChatMapper;
import kr.ac.shingu.appfrm.repository.ChatUser;
import kr.ac.shingu.appfrm.repository.ChatUserRepository;

@RestController
public class LoginRestController {
    private final Logger log = LoggerFactory.getLogger(LoginRestController.class);
    private final ChatUserRepository chatUserRepository;
    private final ChatMapper chatMapper;
    
    public LoginRestController(ChatUserRepository chatUserRepository, ChatMapper chatMapper) {
        this.chatUserRepository = chatUserRepository;
        this.chatMapper = chatMapper;
    }

    @PostMapping(path = "/login", consumes = { "application/json" })
    public ResponseData login(@RequestBody LoginData loginData,
                              HttpServletRequest request) throws Exception {
        this.log.debug("" + loginData);

        String userId = loginData.getUserId();
        String userPwd = loginData.getUserPwd();

        // 1. 사용자 ID로 DB에서 사용자 정보 조회
        Optional<ChatUser> chatUserOpt = this.chatUserRepository.findById(userId);
        
        ChatUser chatUser = this.chatMapper.selectChatUserById(userId);
        if(chatUser == null) {
        	return new ResponseData(false, "ID나 패스워드가 잘못되었습니다.");
        }
        // 3. 패스워드 일치 여부 확인
        if (chatUser.getUserPwd().equals(userPwd) == false) {
            return new ResponseData(false, "ID나 패스워드가 잘못되었습니다.");
        }

        // 4. 기존 세션이 있다면 무효화
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        // 5. 새 세션 생성 및 사용자 ID 저장 (로그인 처리)
        session = request.getSession(true);
        session.setAttribute("userId", userId);

        // 6. 로그인 성공 응답 반환
        return new ResponseData(true, "로그인 되었습니다.");
    }
}
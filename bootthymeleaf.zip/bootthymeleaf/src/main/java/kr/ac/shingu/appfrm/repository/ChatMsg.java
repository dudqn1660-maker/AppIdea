package kr.ac.shingu.appfrm.repository;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
@Table(name="chat_msg")
public class ChatMsg {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="msg_id", nullable=false)
	private long msgId;
	@Column(name="nickname", nullable=false)
	private String nickname;
	@Column(name="chat_content", nullable=false)
	private String chatContent;
	@Column(name="chat_cre_time", nullable=false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date chatCreTime;
	 
    // **[추가] JPA 사용을 위해 필수적인 기본 생성자**
    public ChatMsg() {
        super();
    }

	@Override
	public String toString() {
		return "ChatMsg [msgId=" + msgId + ", nickname=" + nickname + ", chatContent=" + chatContent + ", chatCreTime="
				+ chatCreTime + "]";
	}
	public long getMsgId() {
		return msgId;
	}
	public void setMsgId(long msgId) {
		this.msgId = msgId;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getChatContent() {
		return chatContent;
	}
	public void setChatContent(String chatContent) {
		this.chatContent = chatContent;
	}
	public Date getChatCreTime() {
		return chatCreTime;
	}
	public void setChatCreTime(Date chatCreTime) {
		this.chatCreTime = chatCreTime;
	}
	public ChatMsg(long msgId, String nickname, String chatContent, Date chatCreTime) {
		super();
		this.msgId = msgId;
		this.nickname = nickname;
		this.chatContent = chatContent;
		this.chatCreTime = chatCreTime;
	}
}
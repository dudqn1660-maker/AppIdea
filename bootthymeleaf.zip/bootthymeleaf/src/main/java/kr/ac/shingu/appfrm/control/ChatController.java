package kr.ac.shingu.appfrm.control;

import java.io.PrintWriter;
import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpServletResponse;
import kr.ac.shingu.appfrm.service.ChatService;

@Controller
@RequestMapping("/chat")
public class ChatController {
    private final Logger log = LoggerFactory.getLogger(ChatController.class);
    
    /*
    private ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @GetMapping("/poll")
    @ResponseBody
    public void poll(@RequestParam("nickname") String nickname,
                     HttpServletResponse response) throws Exception {
        BlockingQueue<String> queue = this.chatService.addUser(nickname);
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();

        while (true) {
            this.log.debug(nickname + " poll");
            // block
            String msg = queue.take();
            this.log.debug(nickname + " took " + msg);
            out.println("<script>parent.addMessage(\"" + msg + "\");</script>");
            out.flush(); // response buffer
        }
    }

    @PostMapping("/push")
    @ResponseBody
    public void push(@RequestParam("nickname") String nickname,
                     @RequestParam("msg") String msg,
                     HttpServletResponse response) throws Exception {
        this.chatService.addMessage(nickname, msg);
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.println("OK");
    }
  
  */
    
}

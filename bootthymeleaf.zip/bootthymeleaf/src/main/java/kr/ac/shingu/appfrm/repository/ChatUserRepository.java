package kr.ac.shingu.appfrm.repository;

// 🚨 삭제해야 할 잘못된 Import
// import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties.Sort; 

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
// CrudRepository는 findAll() 메서드를 포함한 기본 CRUD 기능을 제공하며,
// <엔티티 클래스, 엔티티 ID의 자료형>입니다.
public interface ChatUserRepository extends CrudRepository<ChatUser, String> {

}
package kr.ac.shingu.appfrm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import kr.ac.shingu.appfrm.repository.ChatMsg;
import kr.ac.shingu.appfrm.repository.ChatUser;

@Mapper
public interface ChatMapper {

    public ChatUser selectChatUserById(String id);

    public int insertChatUser(ChatUser chatUser);
    public List<ChatMsg> selectAllChatMsg(String order);
    public long selectNextMsgId();
    public int insertChatMsg(ChatMsg chatMsg);
}
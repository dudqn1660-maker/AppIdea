package kr.ac.shingu.appfrm.control;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute; // 추가
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // 추가

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import kr.ac.shingu.appfrm.mapper.ChatMapper;
import kr.ac.shingu.appfrm.repository.ChatUser;
import kr.ac.shingu.appfrm.repository.ChatUserRepository;
import kr.ac.shingu.appfrm.service.ChatService;

@Controller
@RequestMapping("/")
public class LoginController {

    private final Logger log = LoggerFactory.getLogger(LoginController.class);
    
    private final ChatService chatService;
    private final ChatMapper chatMapper;

   
    /*public LoginController() {
    }

    @GetMapping("")
    public String index() {
        this.log.debug("index");
        return "index";
    }

    @PostMapping("main")
    public String main(@RequestParam("nickname") String nickname, Model model) {
        this.log.debug("main");
        model.addAttribute("nickname", nickname);
        return "main";
    }*/
    

	private final ChatUserRepository chatUserRepository;
			public LoginController(ChatUserRepository chatUserRepository,  ChatService chatService, ChatMapper 
					chatMapper) {
			this.chatUserRepository = chatUserRepository;
			this.chatService = chatService; 
			this.chatMapper = chatMapper;
	}
    
    @GetMapping("")
    // @ModelAttribute를 사용하여 RedirectAttributes에서 전달된 loginError를 받습니다.
    public String index(HttpSession session, Model model, @ModelAttribute("loginError") String loginError) {
        String userId = (String) session.getAttribute("userId");

        // 로그인되지 않은 경우
        if (userId == null) {
            // loginError 메시지가 있다면 model에 추가하여 login 뷰로 전달합니다.
            if (loginError != null && !loginError.isEmpty()) {
                model.addAttribute("loginError", loginError);
            }
            return "login";
        }

        // 로그인된 경우
        Optional<ChatUser> chatUserOpt = this.chatUserRepository.findById(userId);

        if (chatUserOpt.isEmpty()) {
            // 세션은 있으나 DB에서 사용자를 못 찾은 경우
            return "login";
        }
        
        

        ChatUser chatUser = this.chatMapper.selectChatUserById(userId);
        if(chatUser == null) {
        return "login";
        }
        String nickname = chatUser.getNickname();

        model.addAttribute("nickname", nickname);
        
 
        String prevMsg = this.chatService.loadAllChatMsg();
        this.log.debug("prevMsg: " + prevMsg);
        model.addAttribute("prevMsg", prevMsg);
        
        return "main";
    }
    
    
    @PostMapping(path="login", consumes = {"application/x-www-form-urlencoded"})
    // Model 대신 RedirectAttributes를 사용하여 로그인 실패 메시지를 일회성으로 전달합니다.
    public String login(@RequestParam("userId") String userId, @RequestParam("userPwd") String userPwd, HttpServletRequest request, RedirectAttributes redirectAttributes) {
    	this.log.debug("userId:" + userId + ", pwd: " + userPwd);
    	
    	Optional<ChatUser> chatUserOpt = this.chatUserRepository.findById(userId);
        
        // 1. 사용자 ID 없음
    	if(chatUserOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("loginError", "존재하지 않는 사용자 ID입니다.");
    		return "redirect:/"; // POST-Redirect-GET 패턴 사용
    	}
    	
    	 ChatUser chatUser = this.chatMapper.selectChatUserById(userId);
    	 if(chatUser == null) {
    	 return "login";
    	 }
        
        // 2. 비밀번호 불일치
    	if(chatUser.getUserPwd().equals(userPwd) == false) {
            redirectAttributes.addFlashAttribute("loginError", "비밀번호가 일치하지 않습니다.");
    		return "redirect:/"; // POST-Redirect-GET 패턴 사용
    	}
    	
    	// 인증 성공
    	HttpSession session = request.getSession(false);
    	if(session != null) {
    		session.invalidate();
    	}
    	
    	session = request.getSession(true);
    	session.setAttribute("userId", userId);
    	
    	return "redirect:/";
    	
    }
    
    /*
     * 회원가입
     */
    
    @GetMapping("joinform")
    public String joinform() {
    	return "joinform";
    }
    
    
    @PostMapping("join")
	public String join(ChatUser chatUser) {
		this.log.debug("" + chatUser);
		//this.chatUserRepository.save(chatUser);
		this.chatMapper.insertChatUser(chatUser);
		return "redirect:/";

    }

}
package com.example.bus.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusRouteStopDto {
    private String stationId;
    private String stationName;
    private int stationOrder;
    private boolean turnPoint;
    private String mobileNo;

    // ⭐️ [필수 추가] 이 필드가 있어야 '비상 대책'이 작동합니다!
    private double latitude;
    private double longitude;
}
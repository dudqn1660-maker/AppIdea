package com.example.bus.service;

import com.example.bus.dto.BusStationDto;
import com.example.bus.dto.BusArrivalInfo;
import com.example.bus.dto.BusRouteStopDto;
import com.example.bus.dto.BusLocationDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class BusApiService {

    private static final String GYEONGGI_SERVICE_CODE = "/6410000";

    // ==========================================
    // 🛑 캐싱 설정
    // ==========================================
    private static final long ARRIVAL_CACHE_TTL = 20000;
    private static final long LOCATION_CACHE_TTL = 15000;

    private final WebClient webClient;
    private final String serviceKey;
    private final ObjectMapper objectMapper;

    // ==========================================
    // 📦 메모리 캐시 저장소
    // ==========================================
    private final Map<String, List<BusRouteStopDto>> routeCache = new ConcurrentHashMap<>();
    private final Map<String, CacheEntry<List<BusArrivalInfo>>> arrivalCache = new ConcurrentHashMap<>();
    private final Map<String, CacheEntry<List<BusLocationDto>>> locationCache = new ConcurrentHashMap<>();

    private static class CacheEntry<T> {
        final T data;
        final long timestamp;

        public CacheEntry(T data) {
            this.data = data;
            this.timestamp = System.currentTimeMillis();
        }

        public boolean isExpired(long ttl) {
            return (System.currentTimeMillis() - timestamp) > ttl;
        }
    }

    public BusApiService(WebClient.Builder webClientBuilder,
                         @Value("${api.bus.base-url}") String baseUrl,
                         @Value("${api.bus.service-key}") String serviceKey) {
        this.webClient = webClientBuilder.baseUrl(baseUrl).build();
        this.serviceKey = serviceKey;
        this.objectMapper = new ObjectMapper();
    }

    private String getEncodedKey() {
        return URLEncoder.encode(serviceKey, StandardCharsets.UTF_8);
    }

    private void printApiLog(String methodName, String responseBody, boolean isCached) {
        if (isCached) {
            System.out.println("♻️ [" + methodName + "] 캐시 데이터 반환");
            return;
        }
        if (responseBody.contains("LIMITED_NUMBER_OF_SERVICE_REQUESTS_EXCEEDS_ERROR") || responseBody.contains("429 Too Many Requests")) {
            System.err.println("🚨🚨🚨 [" + methodName + "] API 한도 초과 (429 Error)");
        } else {
            System.out.println("✅ [" + methodName + "] API 실제 호출 완료");
        }
    }

    // 1. 정류소 검색
    public List<BusStationDto> searchStation(String stationName) {
        String path = GYEONGGI_SERVICE_CODE + "/busstationservice/v2/getBusStationListv2";
        try {
            String rawResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("keyword", stationName)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            printApiLog("searchStation", rawResponse, false);
            return parseJsonList(rawResponse, "busStationList").stream()
                    .map(this::mapToBusStationDtoWithLocation)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.err.println("searchStation Error: " + e.getMessage());
            return Collections.emptyList();
        }
    }

    // 2. 도착 정보 조회
    public List<BusArrivalInfo> fetchBusArrival(String stationId) {
        if (arrivalCache.containsKey(stationId)) {
            CacheEntry<List<BusArrivalInfo>> entry = arrivalCache.get(stationId);
            if (!entry.isExpired(ARRIVAL_CACHE_TTL)) {
                printApiLog("fetchBusArrival", "", true);
                return entry.data;
            }
        }

        String path = GYEONGGI_SERVICE_CODE + "/busarrivalservice/v2/getBusArrivalListv2";
        try {
            String rawResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("stationId", stationId)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            printApiLog("fetchBusArrival", rawResponse, false);

            List<BusArrivalInfo> result = parseJsonList(rawResponse, "busArrivalList").stream()
                    .map(this::mapToBusArrivalInfo)
                    .collect(Collectors.toList());

            if (!result.isEmpty()) {
                arrivalCache.put(stationId, new CacheEntry<>(result));
            }
            return result;

        } catch (Exception e) {
            System.err.println("fetchBusArrival Error: " + e.getMessage());
            if (arrivalCache.containsKey(stationId)) {
                return arrivalCache.get(stationId).data;
            }
            return Collections.emptyList();
        }
    }

    // 3. 노선 정보
    public List<BusRouteStopDto> getBusRoute(String routeId) {
        if (routeCache.containsKey(routeId)) {
            printApiLog("getBusRoute", "", true);
            return routeCache.get(routeId);
        }

        String path = GYEONGGI_SERVICE_CODE + "/busrouteservice/v2/getBusRouteStationListv2";
        try {
            String rawResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("routeId", routeId)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            printApiLog("getBusRoute", rawResponse, false);

            List<BusRouteStopDto> result = parseJsonList(rawResponse, "busRouteStationList").stream()
                    .map(this::mapToBusRouteStopDto)
                    .collect(Collectors.toList());

            if (!result.isEmpty()) {
                routeCache.put(routeId, result);
            }
            return result;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    // 4. 버스 위치
    public List<BusLocationDto> getBusLocations(String routeId) {
        if (locationCache.containsKey(routeId)) {
            CacheEntry<List<BusLocationDto>> entry = locationCache.get(routeId);
            if (!entry.isExpired(LOCATION_CACHE_TTL)) {
                printApiLog("getBusLocations", "", true);
                return entry.data;
            }
        }

        String path = GYEONGGI_SERVICE_CODE + "/buslocationservice/v2/getBusLocationListv2";
        try {
            String rawResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("routeId", routeId)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            printApiLog("getBusLocations", rawResponse, false);

            List<BusLocationDto> result = parseJsonList(rawResponse, "busLocationList").stream()
                    .map(this::mapToBusLocationDto)
                    .collect(Collectors.toList());

            if (!result.isEmpty()) {
                locationCache.put(routeId, new CacheEntry<>(result));
            }
            return result;

        } catch (Exception e) {
            if (locationCache.containsKey(routeId)) {
                return locationCache.get(routeId).data;
            }
            return Collections.emptyList();
        }
    }

    // 5. 주변 정류소
    public List<BusStationDto> searchNearbyStations(double latitude, double longitude, int radius) {
        String path = GYEONGGI_SERVICE_CODE + "/busstationservice/v2/getBusStationAroundListv2";
        try {
            String rawResponse = webClient.get()
                    .uri(uriBuilder -> uriBuilder
                            .path(path)
                            .queryParam("serviceKey", getEncodedKey())
                            .queryParam("y", latitude)
                            .queryParam("x", longitude)
                            .queryParam("radius", radius)
                            .queryParam("_type", "json")
                            .build())
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            printApiLog("searchNearbyStations", rawResponse, false);

            return parseJsonList(rawResponse, "busStationAroundList").stream()
                    .map(this::mapToBusStationDtoWithLocation)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    // =================================================================================
    // 🛠️ 매퍼 (Mapper)
    // =================================================================================

    private List<Map<String, Object>> parseJsonList(String rawResponse, String listKey) {
        try {
            Map<String, Object> responseMap = objectMapper.readValue(rawResponse, Map.class);
            if (responseMap == null || responseMap.get("response") == null) return Collections.emptyList();

            Map<String, Object> msgBody = (Map<String, Object>) ((Map<String, Object>) responseMap.get("response")).get("msgBody");
            if (msgBody == null) return Collections.emptyList();

            Object listObj = msgBody.get(listKey);
            return convertToListOfMaps(listObj);
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private List<Map<String, Object>> convertToListOfMaps(Object listObj) {
        if (listObj == null) return Collections.emptyList();
        if (listObj instanceof List) return (List<Map<String, Object>>) listObj;
        if (listObj instanceof Map) return List.of((Map<String, Object>) listObj);
        return Collections.emptyList();
    }

    private double _parseDouble(Object value) {
        if (value == null) return 0.0;
        try { return Double.parseDouble(value.toString()); } catch (NumberFormatException e) { return 0.0; }
    }

    private int _parseInt(Object value) {
        if (value == null) return 0;
        try { return (int) Double.parseDouble(value.toString()); } catch (NumberFormatException e) { return 0; }
    }

    private BusStationDto mapToBusStationDtoWithLocation(Map<String, Object> json) {
        return new BusStationDto(
                json.get("stationId") != null ? json.get("stationId").toString() : null,
                (String) json.get("stationName"),
                json.get("mobileNo") != null ? json.get("mobileNo").toString() : null,
                _parseDouble(json.get("y")),
                _parseDouble(json.get("x"))
        );
    }

    // ⭐️ [수정] flag와 locationNo1을 매핑하도록 변경됨
    private BusArrivalInfo mapToBusArrivalInfo(Map<String, Object> json) {
        BusArrivalInfo info = new BusArrivalInfo();

        Integer predictTime = _parseInt(json.get("predictTime1"));
        info.setPredictTime(predictTime);
        info.setArrivalInfo(predictTime != null ? predictTime + "분 후" : "정보 없음");

        Object plateNoObj = json.get("plateNo1");
        info.setPlateNo((plateNoObj == null || plateNoObj.toString().isEmpty()) ? "정보 없음" : plateNoObj.toString());

        info.setCongestion(_parseInt(json.get("crowded1")));
        info.setRouteId(json.get("routeId") != null ? json.get("routeId").toString() : null);
        info.setRouteName(json.get("routeName") != null ? json.get("routeName").toString() : null);

        Integer routeTypeCd = _parseInt(json.get("routeTypeCd"));
        info.setRouteTypeCd(routeTypeCd);
        info.setRouteType(getRouteTypeName(routeTypeCd));

        // ⭐️ [NEW] 막차/막전 정보를 위해 추가된 매핑
        info.setLocationNo1(_parseInt(json.get("locationNo1"))); // 남은 정류장 수
        info.setFlag((String) json.get("flag")); // 버스 상태 (STOP, WAIT 등)

        return info;
    }

    private BusRouteStopDto mapToBusRouteStopDto(Map<String, Object> json) {
        String turnYn = (String) json.get("turnYn");
        boolean turnPoint = "Y".equals(turnYn);
        String mobileNo = json.get("mobileNo") != null ? json.get("mobileNo").toString() : "";
        double lat = _parseDouble(json.get("y"));
        if (lat == 0.0) lat = _parseDouble(json.get("gpsY"));
        double lon = _parseDouble(json.get("x"));
        if (lon == 0.0) lon = _parseDouble(json.get("gpsX"));
        return new BusRouteStopDto(
                json.get("stationId").toString(),
                (String) json.get("stationName"),
                _parseInt(json.get("stationSeq")),
                turnPoint,
                mobileNo,
                lat,
                lon
        );
    }

    private BusLocationDto mapToBusLocationDto(Map<String, Object> json) {
        double latitude = _parseDouble(json.get("gpsY"));
        if (latitude == 0.0) latitude = _parseDouble(json.get("y"));
        if (latitude == 0.0) latitude = _parseDouble(json.get("lat"));
        double longitude = _parseDouble(json.get("gpsX"));
        if (longitude == 0.0) longitude = _parseDouble(json.get("x"));
        if (longitude == 0.0) longitude = _parseDouble(json.get("lng"));
        return new BusLocationDto(
                json.get("stationId").toString(),
                _parseInt(json.get("stationSeq")),
                (String) json.get("plateNo"),
                latitude,
                longitude,
                null,
                json.get("routeId") != null ? json.get("routeId").toString() : ""
        );
    }

    private String getRouteTypeName(Integer code) {
        if (code == null) return "정보 없음";
        return switch (code) {
            case 11 -> "직행좌석";
            case 12 -> "좌석버스";
            case 13 -> "일반버스";
            case 14 -> "광역버스";
            case 15 -> "경기순환";
            case 16 -> "시외버스";
            case 20 -> "마을버스";
            case 21 -> "따복버스";
            default -> "기타";
        };
    }
}
import 'package:flutter/material.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';

class FavoriteStationCard extends StatefulWidget {
  final BusStation station;
  final VoidCallback onRemove;

  const FavoriteStationCard({
    Key? key,
    required this.station,
    required this.onRemove,
  }) : super(key: key);

  @override
  State<FavoriteStationCard> createState() => _FavoriteStationCardState();
}

class _FavoriteStationCardState extends State<FavoriteStationCard> {
  final BusApiService _apiService = BusApiService();
  late Future<List<BusArrivalInfo>> _arrivalInfoFuture;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    setState(() {
      _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
    });
  }

  void _navigateToDetail() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: widget.station)),
    ).then((_) => _refresh());
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        children: [
          // 1. 카드 헤더
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 10, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.station.stationName,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF2D3436)),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 6),
                      // ⭐️ [수정됨] mobileNo(5자리 번호) 우선 표시
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Text(
                          'ID ${widget.station.mobileNo ?? widget.station.stationId}',
                          style: TextStyle(color: Colors.grey[600], fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                // ⭐️ [수정] 삭제 아이콘을 휴지통으로 변경
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded, color: Colors.grey, size: 20),
                  onPressed: widget.onRemove,
                  tooltip: '즐겨찾기 해제',
                ),
              ],
            ),
          ),

          const Divider(height: 20, indent: 20, endIndent: 20),

          // 2. 도착 정보 리스트 (미리보기)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: FutureBuilder<List<BusArrivalInfo>>(
              future: _arrivalInfoFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Padding(
                    padding: EdgeInsets.all(10.0),
                    child: Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))),
                  );
                }
                if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.info_outline, size: 16, color: Colors.grey[400]),
                        const SizedBox(width: 6),
                        Text("도착 예정 정보가 없습니다.", style: TextStyle(color: Colors.grey[500], fontSize: 13)),
                      ],
                    ),
                  );
                }

                final arrivals = snapshot.data!.take(2).toList(); // 최대 2개만 미리보기

                return Column(
                  children: [
                    ...arrivals.map((arrival) => _buildArrivalRow(arrival)),
                    const SizedBox(height: 12),
                    // 더보기 버튼
                    InkWell(
                      onTap: _navigateToDetail,
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F7FA),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Center(
                          child: Text("상세 정보 보기", style: TextStyle(color: Color(0xFF3B5998), fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildArrivalRow(BusArrivalInfo arrival) {
    final String timeText = arrival.predictTime != null ? '${arrival.predictTime}분 후' : (arrival.arrivalInfo ?? '-');
    final bool isSoon = (arrival.predictTime ?? 99) <= 5;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Text(arrival.routeName ?? '', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF3B5998))),
          const Spacer(),
          Text(timeText, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: isSoon ? Colors.redAccent : Colors.black87)),
        ],
      ),
    );
  }
}
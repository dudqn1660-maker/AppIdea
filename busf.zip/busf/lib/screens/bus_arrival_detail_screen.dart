import 'package:flutter/material.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/screens/bus_route_screen.dart';

class BusArrivalDetailScreen extends StatefulWidget {
  final BusStation station;
  const BusArrivalDetailScreen({Key? key, required this.station}) : super(key: key);

  @override
  State<BusArrivalDetailScreen> createState() => _BusArrivalDetailScreenState();
}

class _BusArrivalDetailScreenState extends State<BusArrivalDetailScreen> {
  final BusApiService _apiService = BusApiService();
  late Future<List<BusArrivalInfo>> _arrivalInfoFuture;

  @override
  void initState() {
    super.initState();
    // 실제 API 호출 로직
    _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
  }

  void _refreshArrivalInfo() {
    setState(() {
      _arrivalInfoFuture = _apiService.fetchBusArrival(widget.station.stationId);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('도착 정보를 새로고침했습니다.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    // 하단 시스템 네비게이션 바 높이 구하기
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('도착 정보', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _refreshArrivalInfo,
          ),
        ],
      ),
      body: Column(
        children: [
          _buildStationHeader(),
          Expanded(
            child: FutureBuilder<List<BusArrivalInfo>>(
              future: _arrivalInfoFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: Color(0xFF3B5998)));
                }
                if (snapshot.hasError) {
                  return _buildErrorView('정보 로딩 실패', Icons.error_outline);
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return _buildErrorView('도착 예정인 버스가 없습니다.', Icons.bus_alert);
                }

                final arrivals = snapshot.data!;

                return ListView.separated(
                  // 하단 패딩 추가
                  padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPadding + 20),
                  itemCount: arrivals.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    return _buildArrivalCard(arrivals[index]);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStationHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4))],
      ),
      child: Column(
        children: [
          const Icon(Icons.location_on, color: Color(0xFF3B5998), size: 32),
          const SizedBox(height: 10),
          Text(
            widget.station.stationName,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Color(0xFF2D3436)),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildArrivalCard(BusArrivalInfo arrival) {
    final String routeType = arrival.routeType ?? '일반';

    // ⭐️ [제거됨]: locationText 변수 및 관련 로직 제거

    // 시간 텍스트
    final String timeText = arrival.predictTime != null
        ? '${arrival.predictTime}분 후'
        : (arrival.arrivalInfo ?? '정보없음');

    final bool isSoon = (arrival.predictTime ?? 99) <= 5;

    // 막차 상태 가져오기 (0:일반, 1:막전, 2:막차)
    final int busStatus = arrival.lastBusStatus;

    // "몇 대 남음" 문구 생성
    String? remainingMessage;
    Color messageColor = Colors.transparent;

    if (busStatus == 2) {
      remainingMessage = "오늘 운행 종료까지 1대 남음 (막차)";
      messageColor = Colors.redAccent;
    } else if (busStatus == 1) {
      remainingMessage = "오늘 운행 종료까지 2대 남음 (다음이 막차)";
      messageColor = Colors.orange;
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            if (arrival.routeId != null) {
              Navigator.push(context, MaterialPageRoute(
                  builder: (context) => BusRouteScreen(routeId: arrival.routeId!, routeName: arrival.routeName ?? '')));
            }
          },
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    // 좌측: 버스 번호
                    SizedBox(
                      width: 80,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            arrival.routeName ?? '000',
                            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF3B5998)),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: _getBadgeColor(routeType).withOpacity(0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              routeType,
                              style: TextStyle(color: _getBadgeColor(routeType), fontSize: 11, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // 중앙: 도착 시간 정보
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            children: [
                              Text(
                                timeText, // 시간만 표시
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: isSoon ? Colors.redAccent : Colors.black87,
                                ),
                              ),
                              // ⭐️ [제거됨]: locationText 표시 부분 제거
                            ],
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              _buildCongestionBadge(arrival.congestion),
                              const SizedBox(width: 6),
                              Text(arrival.plateNo ?? '', style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey),
                  ],
                ),

                // 막차/막전일 때만 하단에 안내 문구 표시
                if (remainingMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: messageColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: messageColor.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, size: 16, color: messageColor),
                          const SizedBox(width: 6),
                          Text(
                            remainingMessage,
                            style: TextStyle(
                              color: messageColor,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCongestionBadge(int? congestion) {
    String text;
    Color color;
    switch (congestion) {
      case 1: text = '여유'; color = Colors.green; break;
      case 2: text = '보통'; color = Colors.orange; break;
      case 3: text = '혼잡'; color = Colors.red; break;
      case 4: text = '매우 혼잡'; color = const Color(0xFF8B0000); break;
      default: text = '정보없음'; color = Colors.grey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: color.withOpacity(0.5)),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  Color _getBadgeColor(String type) {
    if (type.contains('마을')) return Colors.green;
    if (type.contains('직행')) return Colors.redAccent;
    if (type.contains('광역')) return Colors.purple;
    return Colors.blueAccent;
  }

  Widget _buildErrorView(String msg, IconData icon) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 60, color: Colors.grey[300]),
          const SizedBox(height: 16),
          Text(msg, style: TextStyle(color: Colors.grey[500], fontSize: 16), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
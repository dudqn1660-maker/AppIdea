import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class NearbyTab extends StatefulWidget {
  const NearbyTab({Key? key}) : super(key: key);

  @override
  State<NearbyTab> createState() => _NearbyTabState();
}

class _NearbyTabState extends State<NearbyTab> {
  final BusApiService _apiService = BusApiService();
  Future<List<BusStation>>? _nearbyStationsFuture;
  Position? _currentPosition;
  final int _fixedRadius = 500;
  final MapController _mapController = MapController();
  List<Marker> _markers = [];
  bool _mapReady = false;
  static const LatLng _initialCenter = LatLng(37.5665, 126.9780);

  @override
  void initState() {
    super.initState();
    _checkLocationAndLoad();
  }

  Future<void> _checkLocationAndLoad() async {
    setState(() {
      _mapReady = false;
      _markers = [];
      _nearbyStationsFuture = null;
    });

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return;
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return;
    }
    if (permission == LocationPermission.deniedForever) return;

    try {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
      _currentPosition = position;
      final currentLatLng = LatLng(position.latitude, position.longitude);

      _mapController.move(currentLatLng, 16.0);

      _nearbyStationsFuture = _apiService.searchNearbyStations(position.latitude, position.longitude, _fixedRadius);
      await _updateMapMarkers(await _nearbyStationsFuture!);

      if (mounted) setState(() => _mapReady = true);
    } catch (e) {
      if (mounted) setState(() => _nearbyStationsFuture = Future.error(e));
    }
  }

  Future<void> _updateMapMarkers(List<BusStation> stations) async {
    final List<Marker> newMarkers = [];
    if (_currentPosition != null) {
      newMarkers.add(Marker(
        width: 40.0, height: 40.0,
        point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
        child: Container(
          decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Colors.blueAccent, width: 3), boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)]),
          child: const Icon(Icons.my_location, color: Colors.blueAccent, size: 24),
        ),
      ));
    }

    for (var station in stations) {
      newMarkers.add(Marker(
        width: 40.0, height: 40.0,
        point: LatLng(station.latitude, station.longitude),
        child: GestureDetector(
          onTap: () => _navigateToDetail(station),
          child: Container(
            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: const Color(0xFF3B5998), width: 2), boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)]),
            child: const Icon(Icons.directions_bus_rounded, color: Color(0xFF3B5998), size: 22),
          ),
        ),
      ));
    }
    if (mounted) setState(() => _markers = newMarkers);
  }

  void _navigateToDetail(BusStation station) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: station)));
  }

  @override
  Widget build(BuildContext context) {
    final initialCenter = _currentPosition != null ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude) : _initialCenter;

    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(initialCenter: initialCenter, initialZoom: 15, onMapReady: () { if (mounted) setState(() => _mapReady = true); }),
            children: [
              TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.example.bus'),
              MarkerLayer(markers: _markers),
            ],
          ),

          // 상단 앱바 (투명 그라데이션 + 버튼)
          Positioned(
            top: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 10, 16, 20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Colors.white.withOpacity(0.9), Colors.white.withOpacity(0)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("내 주변 정류소", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87)),
                  CircleAvatar(
                    backgroundColor: Colors.white,
                    child: IconButton(icon: const Icon(Icons.refresh, color: Colors.black87), onPressed: _checkLocationAndLoad),
                  )
                ],
              ),
            ),
          ),

          // 하단 정류소 리스트 (Bottom Sheet 스타일)
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 280,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 20, offset: Offset(0, -5))],
              ),
              child: Column(
                children: [
                  Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2))),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text('가까운 정류소 (${_markers.length > 1 ? _markers.length - 1 : 0})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                  Expanded(
                    child: FutureBuilder<List<BusStation>>(
                      future: _nearbyStationsFuture,
                      builder: (context, snapshot) {
                        if (!snapshot.hasData || snapshot.data!.isEmpty) {
                          return Center(child: Text(_mapReady ? '주변에 정류소가 없습니다.' : '위치 확인 중...', style: TextStyle(color: Colors.grey[400])));
                        }
                        return ListView.separated(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                          itemCount: snapshot.data!.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 12),
                          itemBuilder: (context, index) {
                            final station = snapshot.data![index];
                            return Material(
                              color: Colors.grey[50],
                              borderRadius: BorderRadius.circular(12),
                              child: InkWell(
                                onTap: () {
                                  _mapController.move(LatLng(station.latitude, station.longitude), 17.0);
                                  _navigateToDetail(station);
                                },
                                borderRadius: BorderRadius.circular(12),
                                child: Padding(
                                  padding: const EdgeInsets.all(12.0),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(color: Colors.blueAccent.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                                        child: const Icon(Icons.directions_bus, color: Colors.blueAccent, size: 20),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(station.stationName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                            const SizedBox(height: 2),
                                            Text(station.mobileNo ?? '-', style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                                          ],
                                        ),
                                      ),
                                      const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.grey),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
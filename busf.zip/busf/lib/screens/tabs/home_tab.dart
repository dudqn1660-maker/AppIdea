import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:bus/screens/bus_arrival_detail_screen.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/screens/destination_search_screen.dart';
// ⭐️ [필수] 상태 서비스 및 네비게이션 화면 임포트
import 'package:bus/services/navigation_state_service.dart';
import 'package:bus/screens/navigation_screen.dart';

class RouteBusInfo {
  final String routeId;
  final String routeName;
  final String routeType;

  RouteBusInfo({required this.routeId, required this.routeName, required this.routeType});
}

class FavoriteItem {
  final String stationId;
  final String routeId;
  final String stationName;
  final String routeName;

  FavoriteItem({
    required this.stationId,
    required this.routeId,
    required this.stationName,
    required this.routeName,
  });
}

class HomeTab extends StatefulWidget {
  final ValueChanged<int>? onTabChange;

  const HomeTab({Key? key, this.onTabChange}) : super(key: key);

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final BusApiService _apiService = BusApiService();
  // ⭐️ 네비게이션 상태 서비스 인스턴스
  final NavigationStateService _navService = NavigationStateService();

  late Future<List<BusStation>> _nearbyStationsFuture = Future.value([]);

  final List<FavoriteItem> _favoriteRoutes = [
    FavoriteItem(stationId: '200000057', routeId: '233000188', stationName: '판교역 동편', routeName: '900'),
    FavoriteItem(stationId: '200000055', routeId: '233000047', stationName: '삼평교', routeName: '101'),
  ];

  @override
  void initState() {
    super.initState();
    _loadNearbyStations();
    // ⭐️ 안내 상태 변경 감지 리스너 등록
    _navService.addListener(_onNavStateChanged);
  }

  @override
  void dispose() {
    // ⭐️ 리스너 해제
    _navService.removeListener(_onNavStateChanged);
    super.dispose();
  }

  void _onNavStateChanged() {
    if (mounted) setState(() {});
  }

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return Future.error('위치 서비스를 활성화해주세요.');

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return Future.error('위치 권한이 거부되었습니다.');
    }

    if (permission == LocationPermission.deniedForever) return Future.error('위치 권한을 영구적으로 허용해주세요.');

    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.medium);
  }

  Future<List<BusStation>> _getNearbyStationsFuture() async {
    try {
      final Position position = await _determinePosition();
      return await _apiService.searchNearbyStations(position.latitude, position.longitude, 500);
    } catch (e) {
      throw Exception('위치 정보 로딩 실패');
    }
  }

  void _loadNearbyStations() {
    setState(() {
      _nearbyStationsFuture = _getNearbyStationsFuture();
    });
  }

  void _refreshAllData() {
    _loadNearbyStations();
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('새로고침 완료!')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.directions_bus_filled_rounded, color: Color(0xFF3B5998)),
            SizedBox(width: 8),
            Text('경기버스 알리미', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF2D3436))),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
            onPressed: _refreshAllData,
          ),
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded, color: Colors.black87),
            onPressed: () {},
          ),
        ],
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [
            _buildSearchBar(),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("빠른 실행", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
                        const SizedBox(height: 12),

                        // ⭐️ 안내 중이면 카드 표시, 아니면 퀵 버튼 표시
                        _navService.isNavigating
                            ? _buildActiveNavigationCard()
                            : _buildQuickActions(),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),

                  _buildSectionHeader('즐겨찾는 노선', Icons.star_rounded, Colors.amber, 3),
                  _buildFavoriteRoutes(),

                  const SizedBox(height: 24),

                  _buildSectionHeader('내 주변 정류장', Icons.near_me_rounded, Colors.blueAccent, 2),
                  _buildNearbyStations(),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ⭐️ 안내 중일 때 표시되는 카드
  Widget _buildActiveNavigationCard() {
    final bus = _navService.currentBus;
    final endStation = _navService.endStation;

    if (bus == null) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () {
        // 안내 화면으로 이동 (복구)
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NavigationScreen(
              bus: bus,
              startStation: "현재 위치",
              endStation: endStation ?? "도착지",
            ),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: const Color(0xFF3B5998),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: const Color(0xFF3B5998).withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 6))],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
              child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 28),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("${bus.routeName}번 타고 이동 중", style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text("목적지: ${endStation ?? '-'}", style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 14)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white70, size: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      child: GestureDetector(
        onTap: () => widget.onTabChange!(1),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFF0F2F5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.grey.shade200),
          ),
          child: Row(
            children: [
              const Icon(Icons.search_rounded, color: Colors.grey),
              const SizedBox(width: 12),
              Text('정류장 검색', style: TextStyle(color: Colors.grey[500], fontSize: 15, fontWeight: FontWeight.w500)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon, Color iconColor, int tabIndex) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: iconColor, size: 20),
              ),
              const SizedBox(width: 10),
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
            ],
          ),
          GestureDetector(
            onTap: () => widget.onTabChange!(tabIndex),
            child: const Text('더보기', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.w600, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Widget _buildFavoriteRoutes() {
    return Column(
      children: _favoriteRoutes.map((fav) {
        Future<BusArrivalInfo?> arrivalFuture = _apiService.fetchArrivalInfoByRoute(
          stationId: fav.stationId,
          routeId: fav.routeId,
        );

        return FutureBuilder<BusArrivalInfo?>(
          key: ValueKey(fav.routeId + fav.stationId),
          future: arrivalFuture,
          builder: (context, snapshot) {
            String timeText = '로딩중..';
            Color timeColor = Colors.grey;

            if (snapshot.hasData && snapshot.data!.predictTime != null) {
              final time = snapshot.data!.predictTime!;
              timeText = time <= 0 ? '곧 도착' : '$time분 후';
              timeColor = time <= 5 ? Colors.redAccent : const Color(0xFF3B5998);
            } else if (snapshot.connectionState == ConnectionState.done) {
              timeText = '정보없음';
            }

            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                leading: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFF3B5998),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(fav.routeName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
                title: Text(fav.stationName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                trailing: Text(timeText, style: TextStyle(color: timeColor, fontWeight: FontWeight.bold, fontSize: 15)),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) => BusArrivalDetailScreen(station: BusStation(stationId: fav.stationId, stationName: fav.stationName, mobileNo: null, latitude: 0, longitude: 0)),
                  ));
                },
              ),
            );
          },
        );
      }).toList(),
    );
  }

  Widget _buildNearbyStations() {
    return SizedBox(
      height: 160,
      child: FutureBuilder<List<BusStation>>(
        future: _nearbyStationsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text("주변에 정류장이 없습니다.", style: TextStyle(color: Colors.grey[400])));
          }

          return ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: snapshot.data!.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, index) {
              final station = snapshot.data![index];
              return Container(
                width: 140,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => BusArrivalDetailScreen(station: station)));
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.blueAccent.withOpacity(0.1),
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.location_on, color: Colors.blueAccent, size: 20),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(station.stationName, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                              const SizedBox(height: 4),
                              Text("${station.mobileNo ?? '-'}", style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildQuickActions() {
    return ElevatedButton(
      onPressed: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => const DestinationSearchScreen()));
      },
      style: ElevatedButton.styleFrom(
        minimumSize: const Size(double.infinity, 80),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF3B5998),
        elevation: 2,
        shadowColor: Colors.black12,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding: EdgeInsets.zero,
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF3B5998).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.map_rounded, color: Color(0xFF3B5998), size: 32),
            ),
            const SizedBox(width: 20),
            const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("길찾기 / 경로 검색", style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87)),
                SizedBox(height: 4),
                Text("목적지까지 가장 빠른 버스 찾기", style: TextStyle(fontSize: 13, color: Colors.grey)),
              ],
            ),
            const Spacer(),
            const Icon(Icons.arrow_forward_ios_rounded, color: Colors.grey, size: 16),
          ],
        ),
      ),
    );
  }
}
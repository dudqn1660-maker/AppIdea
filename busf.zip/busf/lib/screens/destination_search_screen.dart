import 'package:flutter/material.dart';
import 'package:bus/services/place_service.dart';
import 'package:bus/services/geolocation_service.dart';
// ⭐️ 결과 화면 import
import 'package:bus/screens/route_result_screen.dart';

class DestinationSearchScreen extends StatefulWidget {
  const DestinationSearchScreen({Key? key}) : super(key: key);

  @override
  State<DestinationSearchScreen> createState() => _DestinationSearchScreenState();
}

class _DestinationSearchScreenState extends State<DestinationSearchScreen> {
  final TextEditingController _startController = TextEditingController();
  final TextEditingController _endController = TextEditingController();
  final FocusNode _startFocus = FocusNode();
  final FocusNode _endFocus = FocusNode();

  Place? _startPlace;
  Place? _endPlace;

  final PlaceService _placeService = PlaceService();
  final GeolocationService _geolocationService = GeolocationService();

  List<Place> _searchResults = [];
  bool _isLoading = false;
  bool _isSearchingStart = true;
  bool _isLocating = false;

  @override
  void initState() {
    super.initState();
    _startFocus.addListener(() { if (_startFocus.hasFocus) setState(() => _isSearchingStart = true); });
    _endFocus.addListener(() { if (_endFocus.hasFocus) setState(() => _isSearchingStart = false); });
  }

  @override
  void dispose() {
    _startController.dispose(); _endController.dispose();
    _startFocus.dispose(); _endFocus.dispose();
    super.dispose();
  }

  void _search() async {
    final query = _isSearchingStart ? _startController.text : _endController.text;
    if (query.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() => _isLoading = true);

    try {
      final results = await _placeService.searchPlaces(query);
      setState(() => _searchResults = results);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('검색 실패')));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _onPlaceSelected(Place place) {
    setState(() {
      if (_isSearchingStart) {
        _startPlace = place;
        _startController.text = place.placeName;
        FocusScope.of(context).requestFocus(_endFocus);
      } else {
        _endPlace = place;
        _endController.text = place.placeName;
        FocusScope.of(context).unfocus();
      }
      _searchResults = [];
    });
  }

  void _setCurrentLocationAsStart() async {
    setState(() {
      _isLocating = true;
      _searchResults = []; // 검색 결과 리스트 초기화
    });

    FocusScope.of(context).unfocus();

    try {
      final currentPlace = await _geolocationService.getCurrentLocationAsPlace();
      setState(() {
        _startPlace = currentPlace;
        _startController.text = currentPlace.placeName;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('출발지가 "${currentPlace.placeName}"로 설정되었습니다.')),
        );
        FocusScope.of(context).requestFocus(_endFocus);
      });

    } catch (e) {
      final errorMsg = e.toString().contains('권한') ? e.toString() : '현재 위치를 가져올 수 없습니다. GPS를 확인해주세요.';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMsg)),
      );
    } finally {
      setState(() {
        _isLocating = false;
      });
    }
  }

  void _navigateToRouteResult() {
    if (_startPlace == null || _endPlace == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('출발지와 도착지를 모두 설정해주세요.')));
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RouteResultScreen(
          startPlace: _startPlace!,
          endPlace: _endPlace!,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('경로 검색', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // 1. 상단 입력 영역 (완벽 정렬 버전)
          _buildInputArea(),

          // 2. 검색 결과 리스트
          Expanded(
            child: _isLoading || _isLocating
                ? Center(child: _isLocating
                ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 16),
                Text('현재 위치 찾는 중...', style: TextStyle(color: Colors.grey[500])),
              ],
            )
                : const CircularProgressIndicator()
            )
                : _searchResults.isEmpty
                ? _buildEmptyState()
                : ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 16),
              itemCount: _searchResults.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final place = _searchResults[index];
                return _buildPlaceItem(place);
              },
            ),
          ),

          // 3. 하단 버튼
          if (_startPlace != null && _endPlace != null)
            _buildBottomButton(),
        ],
      ),
    );
  }

  // 🔹 상단 입력 필드 영역 (Stack을 이용한 완벽한 정렬)
  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(30)),
        boxShadow: [
          BoxShadow(color: Colors.black12, blurRadius: 15, offset: Offset(0, 5)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 왼쪽 아이콘 라인 (고정폭)
          Column(
            children: [
              const SizedBox(height: 18), // 텍스트 필드 내부 텍스트 높이에 맞춤 (중요!)
              const Icon(Icons.circle, color: Colors.blueAccent, size: 10),

              // 점선 연결
              Container(
                height: 45, // 입력창 사이 간격에 맞춰 높이 조절
                width: 1,
                margin: const EdgeInsets.symmetric(vertical: 4),
                color: Colors.grey[300],
              ),

              const Icon(Icons.location_on, color: Colors.redAccent, size: 20),
            ],
          ),

          const SizedBox(width: 16), // 아이콘과 입력창 사이 간격

          // 오른쪽 입력창 영역
          Expanded(
            child: Column(
              children: [
                _buildTextField(
                  controller: _startController,
                  focusNode: _startFocus,
                  hint: '출발지 검색 (예: 집)',
                  isStart: true,
                  // ⭐️ [NEW] Text와 Icon이 결합된 버튼 전달
                  leadingWidget: GestureDetector(
                    onTap: _setCurrentLocationAsStart,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.my_location, color: Colors.blueAccent, size: 20),
                          const SizedBox(width: 4),
                          const Text("내 위치", style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12), // 입력창 사이 간격
                _buildTextField(
                  controller: _endController,
                  focusNode: _endFocus,
                  hint: '도착지 검색 (예: 회사)',
                  isStart: false,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔹 텍스트 필드 디자인 (leadingWidget 인자 추가)
  Widget _buildTextField({
    required TextEditingController controller,
    required FocusNode focusNode,
    required String hint,
    required bool isStart,
    Widget? leadingWidget, // ⭐️ 선행 위젯 옵션 추가
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: TextField(
        controller: controller,
        focusNode: focusNode,
        onTap: () => setState(() => _isSearchingStart = isStart),
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, height: 1.2), // 텍스트 높이 조정
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey[400], fontWeight: FontWeight.normal),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          // ⭐️ [수정] Tooltip 제거하고, 전달된 위젯을 그대로 prefix로 사용
          prefixIcon: leadingWidget,
          suffixIcon: IconButton(
            icon: const Icon(Icons.search, color: Colors.grey),
            onPressed: _search,
          ),
        ),
        onSubmitted: (_) => _search(),
      ),
    );
  }

  // 🔹 검색 결과 아이템 (카드형)
  Widget _buildPlaceItem(Place place) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.blue[50],
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.place, color: Colors.blueAccent, size: 24),
        ),
        title: Text(
          place.placeName,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(place.address, style: TextStyle(color: Colors.grey[600], fontSize: 13)),
        ),
        onTap: () => _onPlaceSelected(place),
      ),
    );
  }

  // 🔹 하단 버튼 (Safe Area 적용)
  Widget _buildBottomButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
        child: ElevatedButton(
          onPressed: _navigateToRouteResult,
          style: ElevatedButton.styleFrom(
            minimumSize: const Size(double.infinity, 56),
            backgroundColor: const Color(0xFF3B5998),
            foregroundColor: Colors.white,
            elevation: 4,
            shadowColor: Colors.blueAccent.withOpacity(0.3),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.directions_bus_filled_rounded),
              SizedBox(width: 8),
              Text('경로 분석 및 버스 찾기', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  // 🔹 검색 결과 없음 / 초기 상태
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isSearchingStart ? Icons.my_location_rounded : Icons.location_on_rounded,
            size: 60,
            color: Colors.grey[300],
          ),
          const SizedBox(height: 16),
          Text(
            _isSearchingStart ? '출발지를 검색해주세요.' : '도착지를 검색해주세요.',
            style: TextStyle(color: Colors.grey[400], fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:bus/screens/tabs/home_tab.dart';
import 'package:bus/screens/tabs/search_tab.dart';
import 'package:bus/screens/tabs/nearby_tab.dart';
import 'package:bus/screens/tabs/favorite_tab.dart';

// 앱의 최상위 위젯 (BottomNavigationBar를 관리)
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // 현재 선택된 탭 인덱스

  // 탭 전환 로직
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  // 탭 화면 목록
  late final List<Widget> _tabs = [
    HomeTab(onTabChange: _onItemTapped),
    const SearchTab(),
    const NearbyTab(),
    const FavoriteTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 배경색을 다른 탭들과 통일
      backgroundColor: const Color(0xFFF5F7FA),

      // 현재 선택된 탭의 내용 표시
      body: _tabs[_selectedIndex],

      // ⭐️ 하단 탭 바 (디자인 리뉴얼)
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          // 위쪽 모서리만 둥글게 처리
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          // 위쪽으로 은은한 그림자 추가
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 20,
              spreadRadius: 0,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: BottomNavigationBar(
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home_outlined),
                activeIcon: Icon(Icons.home_rounded),
                label: '홈',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.search_rounded),
                activeIcon: Icon(Icons.search_rounded, size: 28), // 선택 시 약간 커짐
                label: '검색',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.near_me_outlined),
                activeIcon: Icon(Icons.near_me_rounded),
                label: '주변',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.star_outline_rounded),
                activeIcon: Icon(Icons.star_rounded),
                label: '즐겨찾기',
              ),
            ],
            currentIndex: _selectedIndex,
            onTap: _onItemTapped,

            // 🎨 색상 및 스타일 설정
            backgroundColor: Colors.white,
            selectedItemColor: const Color(0xFF3B5998), // 포인트 컬러 (Deep Blue)
            unselectedItemColor: Colors.grey[400],      // 비활성 컬러

            type: BottomNavigationBarType.fixed, // 4개 이상일 때 필수
            showUnselectedLabels: true,
            elevation: 0, // 기본 그림자 제거 (Container 그림자 사용)

            selectedLabelStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              height: 1.5, // 텍스트와 아이콘 간격 조정
            ),
            unselectedLabelStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              height: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}
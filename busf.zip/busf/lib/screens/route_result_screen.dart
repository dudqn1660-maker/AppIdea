import 'package:flutter/material.dart';
import 'package:bus/models/bus_station.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/place_service.dart';
import 'package:bus/services/route_favorite_service.dart';
import 'package:bus/screens/bus_route_screen.dart';

class RouteResultScreen extends StatefulWidget {
  final Place startPlace;
  final Place endPlace;

  const RouteResultScreen({
    Key? key,
    required this.startPlace,
    required this.endPlace,
  }) : super(key: key);

  @override
  State<RouteResultScreen> createState() => _RouteResultScreenState();
}

class _RouteResultScreenState extends State<RouteResultScreen> {
  final BusApiService _apiService = BusApiService();
  final RouteFavoriteService _routeService = RouteFavoriteService();

  bool _isLoading = true;
  String _statusMessage = "경로 분석 시작...";

  // 캐싱용 맵
  final Map<String, List<BusRouteStop>> _routeCache = {};
  // 최종 결과 리스트
  final List<Map<String, dynamic>> _foundRoutes = [];

  @override
  void initState() {
    super.initState();
    _analyzeRoute();
  }

  // ⭐️ [NEW] 새로고침 함수
  void _onRefresh() {
    setState(() {
      _isLoading = true;
      _foundRoutes.clear();
      // 캐시 초기화는 성능상 필요하지 않으므로 routeCache는 유지합니다.
      _statusMessage = "경로 분석 재시작...";
    });
    // 분석 로직 재실행
    _analyzeRoute();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('경로를 새로 분석합니다.')));
  }


  // 이름 비교를 위한 정규화 함수
  String _normalizeName(String name) {
    return name.replaceAll(' ', '')
        .replaceAll('초등학교', '').replaceAll('중학교', '').replaceAll('고등학교', '')
        .replaceAll('대학교', '대').replaceAll('대학', '대').replaceAll('학교', '')
        .replaceAll('역', '').replaceAll('.', '');
  }

  // ⭐️ [핵심] 경로 분석 로직 (최단 구간 선택 알고리즘 적용)
  Future<void> _analyzeRoute() async {
    try {
      // 반경을 너무 넓히면 반대편이나 엉뚱한 골목 정류장이 잡힐 수 있어 700~800m 정도로 조정 추천
      const int searchRadius = 800;
      setState(() => _statusMessage = "1. 반경 ${searchRadius}m 내 정류장을 찾습니다...");

      // 1. 출발지/목적지 주변 정류소 검색
      final results = await Future.wait([
        _apiService.searchNearbyStations(widget.startPlace.lat, widget.startPlace.lng, searchRadius),
        _apiService.searchNearbyStations(widget.endPlace.lat, widget.endPlace.lng, searchRadius),
      ]);

      final startStations = results[0];
      final endStations = results[1];

      if (startStations.isEmpty || endStations.isEmpty) {
        _finishSearch("반경 ${searchRadius}m 내에 정류장이 없습니다.");
        return;
      }

      // 출발지 후보군 (상행, 하행 정류장이 모두 포함될 수 있음)
      final startCandidates = startStations.take(12).toList();
      final endCandidateIds = endStations.map((e) => e.stationId).toSet();
      final String endPlaceNameClean = _normalizeName(widget.endPlace.placeName);

      setState(() => _statusMessage = "2. 버스 도착 정보를 조회 중...");

      // 2. 모든 출발 후보 정류장의 버스 정보 조회
      final List<List<BusArrivalInfo>> allArrivals = await Future.wait(
          startCandidates.map((station) => _apiService.fetchBusArrival(station.stationId))
      );

      // ⭐️ [변경 1] 버스별로 '탑승 가능한 모든 출발 정류장'을 수집
      // 기존: Map<String, BusStation> (1:1 매핑) -> 오류 원인
      // 변경: Map<String, List<BusStation>> (1:N 매핑) -> 상행/하행 모두 고려
      Map<String, BusArrivalInfo> uniqueBusInfo = {};
      Map<String, List<BusStation>> busToStartStations = {};

      for (int i = 0; i < startCandidates.length; i++) {
        final station = startCandidates[i];
        final arrivals = allArrivals[i];

        for (var bus in arrivals) {
          if (bus.routeId == null) continue;

          // 버스 기본 정보 저장 (화면 표시용)
          if (!uniqueBusInfo.containsKey(bus.routeId)) {
            uniqueBusInfo[bus.routeId!] = bus;
          }

          // 이 버스를 탈 수 있는 정류장 리스트에 추가
          if (!busToStartStations.containsKey(bus.routeId)) {
            busToStartStations[bus.routeId!] = [];
          }
          busToStartStations[bus.routeId!]!.add(station);
        }
      }

      setState(() => _statusMessage = "3. 최적의 경로를 분석 중...");

      final busList = uniqueBusInfo.values.toList();

      // ⭐️ [변경 2] 각 버스 노선별로 '가장 짧은 경로' 하나만 임시 저장할 맵
      Map<String, Map<String, dynamic>> bestRoutesMap = {};

      const int batchSize = 20;
      for (int i = 0; i < busList.length; i += batchSize) {
        if (!mounted) return;
        final end = (i + batchSize < busList.length) ? i + batchSize : busList.length;
        final batch = busList.sublist(i, end);

        // 노선 전체 경유지 정보 조회
        final routeFutures = batch.map((bus) async {
          if (_routeCache.containsKey(bus.routeId)) return _routeCache[bus.routeId];
          try {
            final stops = await _apiService.getBusRoute(bus.routeId!);
            _routeCache[bus.routeId!] = stops;
            return stops;
          } catch (e) {
            return null;
          }
        });

        final routeResults = await Future.wait(routeFutures);

        for (int j = 0; j < batch.length; j++) {
          final bus = batch[j];
          final routeStops = routeResults[j];
          final possibleStartStations = busToStartStations[bus.routeId];

          if (routeStops == null || possibleStartStations == null) continue;

          // ⭐️ [변경 3] 모든 출발 후보 정류장 vs 모든 도착 후보 정류장 비교
          for (var startStation in possibleStartStations) {
            // A. 노선상에서 출발 정류장의 위치(인덱스)들 찾기
            List<int> startIndices = [];
            String startNormal = _normalizeName(startStation.stationName);

            for (int k = 0; k < routeStops.length; k++) {
              // ID가 일치하거나, 이름이 매우 유사하면 후보로 등록
              if (routeStops[k].stationId == startStation.stationId) {
                startIndices.add(k);
              } else if (_normalizeName(routeStops[k].stationName).contains(startNormal)) {
                startIndices.add(k);
              }
            }

            // B. 노선상에서 도착 정류장의 위치(인덱스)들 찾기
            List<int> endIndices = [];
            for (int k = 0; k < routeStops.length; k++) {
              final stop = routeStops[k];
              bool isMatch = endCandidateIds.contains(stop.stationId);
              if (!isMatch) {
                String stopNameClean = _normalizeName(stop.stationName);
                if (stopNameClean.contains(endPlaceNameClean) || endPlaceNameClean.contains(stopNameClean)) {
                  isMatch = true;
                }
              }
              if (isMatch) endIndices.add(k);
            }

            // C. 최단 거리 계산 (상행/하행 중 짧은 것 선택)
            for (int sIdx in startIndices) {
              for (int eIdx in endIndices) {
                // 순방향(Start < End)일 때만 유효
                if (eIdx > sIdx) {
                  int distance = eIdx - sIdx;

                  // 기존에 찾은 이 버스의 경로보다 더 짧으면 갱신
                  // 또는 처음 찾은 경로면 저장
                  if (!bestRoutesMap.containsKey(bus.routeId) ||
                      distance < bestRoutesMap[bus.routeId]!['stopCount']) {

                    final realStartStop = routeStops[sIdx];
                    final realEndStop = routeStops[eIdx];

                    bestRoutesMap[bus.routeId!] = {
                      'bus': bus,
                      'startStation': realStartStop.stationName, // 실제 노선표상의 이름
                      'endStation': realEndStop.stationName,
                      'time': bus.arrivalInfo ?? '정보없음',
                      'mobileNo': startStation.mobileNo, // 출발 정류장의 ARS 번호 사용
                      'stopCount': distance,
                    };
                  }
                }
              }
            }
          }
        }
      }

      // 최적의 경로들만 리스트에 담기
      _foundRoutes.addAll(bestRoutesMap.values);

      _finishSearch(null);
    } catch (e) {
      print("Route Analysis Error: $e");
      _finishSearch("분석 중 오류가 발생했습니다.");
    }
  }

  void _finishSearch(String? errorMsg) {
    if (mounted) {
      setState(() {
        _isLoading = false;
        if (errorMsg != null) {
          _statusMessage = errorMsg;
        } else if (_foundRoutes.isEmpty) {
          _statusMessage = "직통 버스를 찾지 못했습니다.\n(반경 800m 이내)";
        } else {
          // 정류장 수가 적은 순서대로 정렬
          _foundRoutes.sort((a, b) => (a['stopCount'] as int).compareTo(b['stopCount'] as int));
          _statusMessage = "${_foundRoutes.length}개의 경로를 찾았습니다.";
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final double bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text('추천 경로', style: TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
        centerTitle: true,
        actions: [
          // ⭐️ [NEW] 새로고침 버튼 추가
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _onRefresh,
          ),
        ],
      ),
      body: _isLoading
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(color: Color(0xFF3B5998)),
            const SizedBox(height: 24),
            Text(_statusMessage, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Colors.black54)),
          ],
        ),
      )
          : Column(
        children: [
          _buildHeader(),
          Expanded(
            child: _foundRoutes.isEmpty
                ? _buildEmptyView()
                : ListView.separated(
              padding: EdgeInsets.fromLTRB(16, 16, 16, bottomPadding + 20),
              itemCount: _foundRoutes.length,
              separatorBuilder: (context, index) => const SizedBox(height: 16),
              itemBuilder: (context, index) {
                final route = _foundRoutes[index];
                return _buildBusCard(route);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4))],
      ),
      padding: const EdgeInsets.fromLTRB(24, 10, 24, 24),
      child: Column(
        children: [
          _buildLocationRow(isStart: true, name: widget.startPlace.placeName),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 11),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Column(
                children: List.generate(3, (index) => Container(width: 2, height: 4, margin: const EdgeInsets.symmetric(vertical: 1), color: Colors.grey[300])),
              ),
            ),
          ),
          const SizedBox(height: 4),
          _buildLocationRow(isStart: false, name: widget.endPlace.placeName),
        ],
      ),
    );
  }

  Widget _buildLocationRow({required bool isStart, required String name}) {
    return Row(
      children: [
        Container(
          width: 24, height: 24,
          decoration: BoxDecoration(
            color: isStart ? const Color(0xFFE3F2FD) : const Color(0xFFFFEBEE),
            shape: BoxShape.circle,
            border: Border.all(color: isStart ? Colors.blueAccent : Colors.redAccent, width: 2),
          ),
          child: Center(
            child: Container(width: 8, height: 8, decoration: BoxDecoration(color: isStart ? Colors.blueAccent : Colors.redAccent, shape: BoxShape.circle)),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.black87), overflow: TextOverflow.ellipsis),
        ),
      ],
    );
  }

  Widget _buildBusCard(Map<String, dynamic> route) {
    final bus = route['bus'] as BusArrivalInfo;
    final String time = route['time'];
    final int stopCount = route['stopCount'] ?? 0;

    final bool isUrgent = time.contains('곧') || (int.tryParse(time.replaceAll(RegExp(r'[^0-9]'), '')) ?? 99) < 5;
    final String displayTime = (time == "정보없음") ? "정보 없음" : "$time 도착 예정";
    final Color timeColor = (time == "정보없음") ? Colors.grey : (isUrgent ? const Color(0xFFD63031) : const Color(0xFF7F8FA6));

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BusRouteScreen(
              routeId: bus.routeId!,
              routeName: bus.routeName!,
              startStation: route['startStation'],
              endStation: route['endStation'],
              busInfo: bus,
              // ⭐️ Place 정보를 BusRouteScreen으로 전달하여 경로 저장 문제를 해결
              startPlace: widget.startPlace,
              endPlace: widget.endPlace,
            ),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.blueGrey.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Stack(
          children: [
            Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: const Color(0xFFF0F4FF), borderRadius: BorderRadius.circular(12)),
                        child: const Icon(Icons.directions_bus_rounded, color: Color(0xFF3B5998), size: 28),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text("${bus.routeName}번", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF2D3436))),
                            const SizedBox(width: 8),
                            if (bus.congestion != null) _buildCongestionBadge(bus.congestion!),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(color: isUrgent ? const Color(0xFFFFEBEE) : const Color(0xFFF5F6FA), borderRadius: BorderRadius.circular(12)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.access_time_rounded, size: 16, color: timeColor),
                      const SizedBox(width: 6),
                      Text(displayTime, style: TextStyle(color: timeColor, fontWeight: FontWeight.bold, fontSize: 15)),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Divider(height: 1, color: Colors.grey[200]),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Column(
                    children: [
                      _buildRouteDetailRow("승차", "${route['startStation']} (No.${route['mobileNo'] ?? '-'})", Colors.blueAccent),
                      Padding(
                        padding: const EdgeInsets.only(left: 7, top: 4, bottom: 4),
                        child: Row(
                          children: [
                            Container(width: 2, height: 20, color: Colors.grey[300]),
                            const SizedBox(width: 20),
                            Text(
                                "(약 $stopCount개 정류장 이동)",
                                style: TextStyle(color: Colors.grey[500], fontSize: 12, fontWeight: FontWeight.w500)
                            ),
                          ],
                        ),
                      ),
                      _buildRouteDetailRow("하차", route['endStation'], Colors.redAccent),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCongestionBadge(int congestion) {
    String text;
    Color color;
    Color textColor = Colors.white;

    switch (congestion) {
      case 1: text = "여유"; color = Colors.green; break;
      case 2: text = "보통"; color = Colors.blue; break;
      case 3: text = "혼잡"; color = Colors.amber; textColor = Colors.black87; break;
      case 4: text = "매우 혼잡"; color = Colors.red; break;
      default: return const SizedBox.shrink();
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
      child: Text(text, style: TextStyle(color: textColor, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildRouteDetailRow(String type, String station, Color color) {
    return Row(
      children: [
        Container(width: 16, height: 16, decoration: BoxDecoration(color: Colors.white, border: Border.all(color: color, width: 4), shape: BoxShape.circle)),
        const SizedBox(width: 12),
        Text(type, style: TextStyle(color: Colors.grey[600], fontSize: 13, fontWeight: FontWeight.w500)),
        const SizedBox(width: 8),
        Expanded(child: Text(station, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black87), overflow: TextOverflow.ellipsis)),
      ],
    );
  }

  Widget _buildEmptyView() {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.search_off_rounded, size: 64, color: Colors.grey[300]), const SizedBox(height: 16), Text(_statusMessage, style: TextStyle(color: Colors.grey[500], fontSize: 16), textAlign: TextAlign.center)]));
  }
}
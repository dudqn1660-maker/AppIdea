import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/models/bus_location.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/notification_service.dart';
import 'package:bus/services/navigation_state_service.dart';

class NavigationScreen extends StatefulWidget {
  final BusArrivalInfo bus;
  final String startStation;
  final String endStation;

  const NavigationScreen({
    Key? key,
    required this.bus,
    required this.startStation,
    required this.endStation,
  }) : super(key: key);

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  final BusApiService _apiService = BusApiService();
  final MapController _mapController = MapController();
  final NavigationStateService _navService = NavigationStateService();

  Timer? _arrivalTimer;

  List<BusRouteStop> _fullRouteStops = [];
  List<LatLng> _busRoutePoints = [];

  StreamSubscription<Position>? _positionStream;
  Position? _currentPosition;
  BusRouteStop? _startNode;
  BusRouteStop? _endNode;

  LatLng? _realtimeBusPosition;
  String? _targetPlateNo;

  // 상태 변수
  bool _isBoarded = false;
  bool _hasAskedAboutBoarding = false; // ⭐️ _isAtPickupStation 변수 삭제됨

  int? _stopsToPickup;
  int _stopsToDropoff = 999;
  String _timeToPickup = "조회중...";

  bool _hasPickupAlerted = false;
  bool _hasDropoffAlerted = false;

  final Color _primaryColor = const Color(0xFF3B5998);

  @override
  void initState() {
    super.initState();

    _initNavigation();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_navService.isNavigating && _navService.currentBus?.routeId == widget.bus.routeId) {
        setState(() {
          _isBoarded = _navService.isBoarded;
          if (_isBoarded) {
            _hasAskedAboutBoarding = true;
          }
        });
      } else {
        _navService.startNavigation(widget.bus, widget.endStation);
      }
    });
  }

  void _cancelNavigation() {
    _arrivalTimer?.cancel();
    _positionStream?.cancel();
    _navService.stopNavigation();
    Navigator.pop(context);
  }

  void _confirmCancelNavigation() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text("안내 종료 확인", style: TextStyle(fontWeight: FontWeight.bold)),
          content: const Text("버스 안내를 정말 종료하시겠습니까?", style: TextStyle(fontSize: 15)),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("취소", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () {
                Navigator.pop(context);
                _cancelNavigation();
              },
              child: const Text("안내 종료", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  void _showBoardingConfirmationDialog() {
    if (!mounted) return;

    NotificationService.showNotification(
      title: "버스 도착!",
      body: "${widget.bus.routeName}번 버스가 도착했습니다. 탑승하셨나요?",
    );

    showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text("탑승 확인", style: TextStyle(fontWeight: FontWeight.bold)),
          content: Text("${widget.bus.routeName}번 버스가 도착했습니다.\n탑승하셨나요, 놓치셨나요?", style: const TextStyle(fontSize: 15)),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop('missed'),
              child: const Text("놓쳤어요", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop('boarded'),
              style: ElevatedButton.styleFrom(
                backgroundColor: _primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("탑승했어요", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    ).then((action) async {
      if (!mounted) return;
      if (action == 'boarded') {
        setState(() {
          _isBoarded = true;
        });
        _navService.setBoarded(true);

        _showAlertDialog(title: "탑승 확인", content: "탑승이 확인되었습니다. 안전한 이동 되세요!", color: Colors.blueAccent);
      } else if (action == 'missed') {
        await _showAlertDialog(
            title: "버스 놓침",
            content: "현재 안내를 종료하고 새로운 버스를 검색할 수 있도록 이전 화면으로 돌아갑니다.",
            color: Colors.redAccent
        );
        _cancelNavigation();
      }
    });
  }

  @override
  void dispose() {
    _mapController.dispose();
    super.dispose();
  }

  String _normalizeName(String name) {
    return name.replaceAll(' ', '').replaceAll('.', '').replaceAll('(', '').replaceAll(')', '').trim();
  }

  Future<void> _showAlertDialog({required String title, required String content, required Color color}) async {
    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              Icon(Icons.notifications_active_rounded, color: color),
              const SizedBox(width: 10),
              Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20)),
            ],
          ),
          content: Text(content, style: const TextStyle(fontSize: 16)),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text("확인", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _initNavigation() async {
    if (widget.bus.routeId == null) return;

    try {
      final stops = await _apiService.getBusRoute(widget.bus.routeId!);

      String startName = _normalizeName(widget.startStation);
      String endName = _normalizeName(widget.endStation);

      int startIndex = stops.indexWhere((s) => _normalizeName(s.stationName).contains(startName));
      int endIndex = stops.indexWhere((s) => _normalizeName(s.stationName).contains(endName));

      if (startIndex == -1) startIndex = 0;
      if (endIndex == -1) endIndex = stops.length - 1;
      if (startIndex > endIndex) {
        int temp = startIndex; startIndex = endIndex; endIndex = temp;
      }

      final routeSegment = stops.sublist(startIndex, endIndex + 1);
      final points = routeSegment
          .where((s) => s.latitude != 0.0 && s.longitude != 0.0)
          .map((s) => LatLng(s.latitude, s.longitude))
          .toList();

      if (mounted) {
        setState(() {
          _fullRouteStops = stops;
          _startNode = stops[startIndex];
          _endNode = stops[endIndex];
          _busRoutePoints = points;
        });
      }

      _startLocationTracking();
      _updateBusInfo();
      _arrivalTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
        _updateBusInfo();
      });

    } catch (e) {
      print("초기화 에러: $e");
    }
  }

  Future<void> _updateBusInfo() async {
    if (_startNode == null) return;

    try {
      if (!_isBoarded) {
        final arrivals = await _apiService.fetchBusArrival(_startNode!.stationId);
        final myBus = arrivals.firstWhere(
              (b) => b.routeId == widget.bus.routeId,
          orElse: () => BusArrivalInfo(routeId: 'none'),
        );

        if (myBus.routeId != 'none') {
          int? stops = myBus.locationNo1 ?? myBus.remainingStops;
          int? minutes = myBus.predictTime1 ?? myBus.predictTime;

          if (stops == null && myBus.arrivalInfo != null) {
            final RegExp regExp = RegExp(r'(\d+)번째');
            final match = regExp.firstMatch(myBus.arrivalInfo!);
            if (match != null) stops = int.tryParse(match.group(1)!);
          }

          if (stops == null && minutes != null) {
            stops = (minutes / 2).ceil();
            if (stops < 1) stops = 1;
          }

          if (mounted) {
            setState(() {
              _stopsToPickup = stops;
              _timeToPickup = minutes != null ? "${minutes}분" : (myBus.arrivalInfo ?? "--");
              _targetPlateNo = myBus.plateNo;
            });
          }

          // 탑승 확인 조건 (위치 조건 제거, 시간/거리 조건 완화)
          bool isArriving = (stops != null && stops <= 1) || (minutes != null && minutes <= 2);

          if (myBus.arrivalInfo != null) {
            String info = myBus.arrivalInfo!;
            if (info.contains('도착') || info.contains('진입') || info.contains('곧')) {
              isArriving = true;
            }
          }

          if (!_isBoarded && !_hasAskedAboutBoarding && isArriving) {
            _hasAskedAboutBoarding = true;
            _showBoardingConfirmationDialog();
          }

          // 알림 호출부 1 (승차 임박)
          if (stops != null && stops > 1 && stops <= 3 && !_hasPickupAlerted) {
            _hasPickupAlerted = true;
            NotificationService.showNotification(
              title: "버스 도착 임박!",
              body: "탑승하실 ${widget.bus.routeName}번 버스가 $stops정거장 전입니다. 승차 준비를 해주세요!",
            );
            _showAlertDialog(
                title: "버스 도착 임박!",
                content: "탑승하실 ${widget.bus.routeName}번 버스가 $stops정거장 전입니다.\n승차 준비를 해주세요!",
                color: Colors.orange
            );
          }
        }
      }

      if (widget.bus.routeId != null && _targetPlateNo != null && !_isBoarded) {
        final locations = await _apiService.getBusLocations(widget.bus.routeId!);
        BusLocation? targetBusLoc;

        try {
          String targetNum = _targetPlateNo!.replaceAll(RegExp(r'[^0-9]'), '');
          if (targetNum.length > 4) targetNum = targetNum.substring(targetNum.length - 4);
          targetBusLoc = locations.firstWhere((loc) => loc.plateNo.replaceAll(RegExp(r'[^0-9]'), '').endsWith(targetNum));
        } catch (_) {}

        if (targetBusLoc != null) {
          double lat = targetBusLoc.latitude;
          double lng = targetBusLoc.longitude;

          if (lat == 0.0 || lng == 0.0) {
            try {
              final currentStation = _fullRouteStops.firstWhere((s) => s.stationId == targetBusLoc!.stationId);
              lat = currentStation.latitude;
              lng = currentStation.longitude;
            } catch (_) {}
          }

          if (lat != 0.0 && lng != 0.0) {
            if (mounted) setState(() => _realtimeBusPosition = LatLng(lat, lng));
          }
        }
      } else if (_isBoarded) {
        if (mounted) setState(() => _realtimeBusPosition = null);
      }
    } catch (e) {
      print("갱신 오류: $e");
    }
  }

  void _startLocationTracking() {
    const locationSettings = LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 5);
    _positionStream = Geolocator.getPositionStream(locationSettings: locationSettings)
        .listen((Position position) {
      if (!mounted) return;
      setState(() => _currentPosition = position);
      _mapController.move(LatLng(position.latitude, position.longitude), 16.5);
      _checkStatus(position);
    });
  }

  void _checkStatus(Position userPos) {
    if (_startNode == null || _fullRouteStops.isEmpty) return;

    int closestIndex = 0;
    double minDistance = double.infinity;

    for (int i = 0; i < _fullRouteStops.length; i++) {
      final stop = _fullRouteStops[i];
      if (stop.latitude == 0.0) continue;
      final dist = Geolocator.distanceBetween(userPos.latitude, userPos.longitude, stop.latitude, stop.longitude);
      if (dist < minDistance) {
        minDistance = dist;
        closestIndex = i;
      }
    }

    int startIndex = _fullRouteStops.indexOf(_startNode!);
    int endIndex = _fullRouteStops.indexOf(_endNode!);

    // ⭐️ [수정됨] 에러 원인 제거: isAtStation 변수와 관련된 로직 삭제
    // bool isAtStation = ... (삭제됨)

    bool isBoarded = closestIndex > startIndex;

    // if (!_isBoarded && isAtStation) _isAtPickupStation = true; (삭제됨)

    if (isBoarded) {
      _isBoarded = true;
    }

    int stopsLeft = endIndex - closestIndex;
    if (stopsLeft < 0) stopsLeft = 0;

    if (mounted) {
      setState(() {
        _stopsToDropoff = stopsLeft;
      });
    }

    if (_isBoarded && !_hasDropoffAlerted) {
      if (_stopsToDropoff <= 2 && _stopsToDropoff > 0) {
        _hasDropoffAlerted = true;
        NotificationService.showNotification(
          title: "하차 준비!",
          body: "${_stopsToDropoff}정거장 후에 목적지(${widget.endStation})입니다. 하차 벨을 눌러주세요!",
        );
        _showAlertDialog(
            title: "하차 준비!",
            content: "${_stopsToDropoff}정거장 후에 목적지(${widget.endStation})입니다.\n하차 벨을 눌러주세요!",
            color: Colors.redAccent
        );
      } else if (_stopsToDropoff == 0) {
        _hasDropoffAlerted = true;
        _showAlertDialog(
            title: "도착 완료",
            content: "목적지에 도착했습니다. 짐 챙겨서 하차하세요!",
            color: Colors.blueAccent
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    String topStatus = _isBoarded
        ? "목적지로 이동 중"
        : "승차 정류장 대기 중";
    Color topColor = _isBoarded ? const Color(0xFF43A047) : Colors.orange;

    String bigNumber = _isBoarded
        ? "$_stopsToDropoff"
        : (_stopsToPickup == null ? "?" : "$_stopsToPickup");

    String descText = _isBoarded
        ? "목적지까지 남은 정거장"
        : "버스가 오기까지 남은 정거장";

    final double bottomPadding = MediaQuery.of(context).padding.bottom + 20;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
            child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: Colors.black87),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: topColor,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [BoxShadow(color: topColor.withOpacity(0.4), blurRadius: 8)],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.directions_bus_rounded, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                topStatus,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14),
              ),
            ],
          ),
        ),
        actions: [],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _currentPosition != null
                  ? LatLng(_currentPosition!.latitude, _currentPosition!.longitude)
                  : const LatLng(37.5665, 126.9780),
              initialZoom: 16.0,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.bus_nav',
              ),
              PolylineLayer(
                polylines: [
                  if (_busRoutePoints.isNotEmpty)
                    Polyline(
                      points: _busRoutePoints,
                      strokeWidth: 6.0,
                      color: _primaryColor.withOpacity(0.8),
                      strokeCap: StrokeCap.round,
                    ),
                ],
              ),
              MarkerLayer(
                markers: [
                  if (_startNode != null)
                    Marker(
                      point: LatLng(_startNode!.latitude, _startNode!.longitude),
                      width: 50, height: 50,
                      child: _buildMarkerIcon(Icons.login_rounded, Colors.blue),
                    ),
                  if (_endNode != null)
                    Marker(
                      point: LatLng(_endNode!.latitude, _endNode!.longitude),
                      width: 60, height: 60,
                      child: _buildDestinationMarker(),
                    ),

                  if (!_isBoarded && _realtimeBusPosition != null)
                    Marker(
                      point: _realtimeBusPosition!,
                      width: 70, height: 70,
                      child: _buildBusMarker(),
                    ),
                  if (_currentPosition != null)
                    Marker(
                      point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
                      width: 70, height: 70,
                      child: _isBoarded ? _buildBusMarker(isMe: true) : _buildUserMarker(),
                    ),
                ],
              ),
            ],
          ),

          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: EdgeInsets.fromLTRB(24, 24, 24, bottomPadding),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 25, offset: const Offset(0, -5)),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("${widget.bus.routeName}번", style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF2D3436))),
                          const SizedBox(height: 4),
                          Text(
                            _isBoarded ? "To. ${widget.endStation}" : "From. ${widget.startStation}",
                            style: TextStyle(fontSize: 14, color: Colors.grey[600], fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _primaryColor.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isBoarded ? Icons.directions_bus_rounded : Icons.watch_later_rounded,
                          color: _primaryColor,
                          size: 24,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F7FA),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(descText, style: TextStyle(fontSize: 15, color: Colors.grey[600], fontWeight: FontWeight.w600)),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.baseline,
                          textBaseline: TextBaseline.alphabetic,
                          children: [
                            Text(
                              bigNumber,
                              style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: _primaryColor),
                            ),
                            const SizedBox(width: 4),
                            const Text("정거장", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black54)),
                          ],
                        ),
                      ],
                    ),
                  ),

                  if (!_isBoarded)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          const Icon(Icons.timer_rounded, size: 14, color: Colors.grey),
                          const SizedBox(width: 4),
                          Text("도착 예정: $_timeToPickup", style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: Colors.grey)),
                        ],
                      ),
                    ),

                  Padding(
                    padding: EdgeInsets.only(top: _isBoarded ? 20 : 12),
                    child: ElevatedButton.icon(
                      onPressed: _confirmCancelNavigation,
                      icon: const Icon(Icons.cancel_rounded, size: 24),
                      label: const Text("안내 취소", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        foregroundColor: Colors.white,
                        minimumSize: const Size(double.infinity, 56),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMarkerIcon(IconData icon, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 4))],
      ),
      child: Icon(icon, color: color, size: 32),
    );
  }

  Widget _buildDestinationMarker() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(color: Colors.redAccent.withOpacity(0.2), shape: BoxShape.circle),
        ),
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: Colors.white, shape: BoxShape.circle,
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6)],
          ),
          child: const Icon(Icons.flag_rounded, color: Colors.redAccent, size: 28),
        ),
      ],
    );
  }

  Widget _buildBusMarker({bool isMe = false}) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 60, height: 60,
          decoration: BoxDecoration(
            color: (isMe ? _primaryColor : Colors.deepOrange).withOpacity(0.2),
            shape: BoxShape.circle,
          ),
        ),
        Container(
          width: 44, height: 44,
          decoration: BoxDecoration(
            color: isMe ? _primaryColor : Colors.deepOrange,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2.5),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 6)],
          ),
          child: const Icon(Icons.directions_bus_rounded, color: Colors.white, size: 22),
        ),
      ],
    );
  }

  Widget _buildUserMarker() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(color: _primaryColor.withOpacity(0.15), shape: BoxShape.circle),
        ),
        Container(
          width: 20, height: 20,
          decoration: BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
            border: Border.all(color: _primaryColor, width: 3),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 4)],
          ),
        ),
      ],
    );
  }
}
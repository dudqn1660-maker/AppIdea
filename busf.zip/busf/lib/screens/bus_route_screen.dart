import 'package:flutter/material.dart';
import 'package:bus/models/bus_route_stop.dart';
import 'package:bus/models/bus_location.dart';
import 'package:bus/models/bus_arrival_info.dart';
import 'package:bus/services/bus_api_service.dart';
import 'package:bus/services/route_favorite_service.dart';
import 'package:bus/services/place_service.dart';
import 'package:bus/screens/navigation_screen.dart';

class BusRouteScreen extends StatefulWidget {
  final String routeId;
  final String routeName;
  final String? startStation;
  final String? endStation;
  final BusArrivalInfo? busInfo;

  final Place? startPlace;
  final Place? endPlace;

  const BusRouteScreen({
    Key? key,
    required this.routeId,
    required this.routeName,
    this.startStation,
    this.endStation,
    this.busInfo,
    this.startPlace,
    this.endPlace,
  }) : super(key: key);

  @override
  State<BusRouteScreen> createState() => _BusRouteScreenState();
}

class _BusRouteScreenState extends State<BusRouteScreen> {
  final BusApiService _apiService = BusApiService();
  final RouteFavoriteService _routeService = RouteFavoriteService();

  late Future<List<BusRouteStop>> _routeFuture;
  late Future<List<BusLocation>> _locationFuture;
  late Future<List<dynamic>> _dataFuture;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    _routeFuture = _apiService.getBusRoute(widget.routeId);
    _locationFuture = _apiService.getBusLocations(widget.routeId);

    setState(() {
      _dataFuture = Future.wait([_routeFuture, _locationFuture]);
    });
  }

  Future<void> _onRefresh() async {
    await _loadData();
    await _dataFuture;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('새로고침 완료')));
  }

  // ⭐️ [롤백] 경로 별명 입력 및 저장 팝업 (원래 디자인으로 복구)
  Future<bool> _onSaveRoute(BuildContext context) async {
    if (widget.startPlace == null || widget.endPlace == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('경로 저장에 필요한 출발/도착 정보가 부족합니다.')));
      return false;
    }

    final defaultName = "${widget.routeName}번 (${widget.startPlace!.placeName} → ${widget.endPlace!.placeName})";
    final nameController = TextEditingController(text: defaultName);

    final bool? saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        // Shape 유지
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            // ⭐️ [롤백] 아이콘을 별 모양 (star_rounded)과 호박색 (amber)으로 복구
            Icon(Icons.star_rounded, color: Colors.amber, size: 24),
            SizedBox(width: 8),
            Text("경로 별명 저장", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          ],
        ),
        titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
        contentPadding: const EdgeInsets.symmetric(horizontal: 24),

        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: nameController,
              autofocus: true,
              decoration: InputDecoration(
                labelText: "경로 별명",
                hintText: "예: 출근길, 등교길",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ],
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        actions: [
          TextButton(
            child: const Text("취소", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            onPressed: () => Navigator.pop(context, false),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              // ⭐️ [롤백] 버튼 색상을 원래의 보라색/진한 파란색 계열로 복구
              backgroundColor: const Color(0xFF3B5998),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            ),
            child: const Text("저장하기", style: TextStyle(fontWeight: FontWeight.bold)),
            onPressed: () async {
              if (nameController.text.isEmpty) return;
              final id = DateTime.now().millisecondsSinceEpoch.toString();

              final newRoute = FavoriteRoute(
                id: id, name: nameController.text, start: widget.startPlace!, end: widget.endPlace!,
              );
              await _routeService.addRoute(newRoute);

              Navigator.pop(context, true);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('✅ 자주 가는 경로에 저장되었습니다!'), behavior: SnackBarBehavior.floating),
              );
            },
          ),
        ],
      ),
    );
    return saved ?? false;
  }

  // ⭐️ [롤백] 경로 안내 시작 팝업 (버튼 색상 복구)
  void _startNavigation() async {
    if (widget.busInfo == null || widget.startStation == null || widget.endStation == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('경로 안내에 필요한 정보가 부족합니다.')));
      return;
    }

    // 1. 즐겨찾기 추가 여부를 묻는 팝업 (await)
    final bool? shouldSave = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text("경로 안내 시작", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          content: const Text("이 경로를 즐겨찾기에 추가하시겠습니까?", style: TextStyle(fontSize: 15)),

          titlePadding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
          contentPadding: const EdgeInsets.fromLTRB(24, 16, 24, 24),

          actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, false), // false 반환 (저장 안 함)
              child: const Text("추가 안 함", style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                // ⭐️ [롤백] 버튼 색상을 원래의 보라색/진한 파란색 계열로 복구
                backgroundColor: const Color(0xFF3B5998),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
              onPressed: () => Navigator.pop(context, true), // true 반환 (저장 후 시작)
              child: const Text("저장 후 시작", style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        );
      },
    );

    if (shouldSave == true) {
      // 2. 저장 옵션이 선택되었다면, 별명 입력 팝업을 띄우고 완료될 때까지 기다림 (await)
      await _onSaveRoute(context);
    }

    // 3. (저장 여부와 관계없이) 최종적으로 안내 화면으로 이동
    _navigateToNavigationScreen();
  }

  void _navigateToNavigationScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NavigationScreen(
          bus: widget.busInfo!,
          startStation: widget.startStation!,
          endStation: widget.endStation!,
        ),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final bool isNavMode = widget.startStation != null && widget.endStation != null;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F7FA),
        appBar: AppBar(
          title: Column(
            children: [
              Text('${widget.routeName}번 노선', style: const TextStyle(color: Colors.black87, fontWeight: FontWeight.bold)),
              if (isNavMode)
                Text("승차: ${widget.startStation} → 하차: ${widget.endStation}", style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.normal)),
            ],
          ),
          backgroundColor: Colors.white,
          elevation: 0,
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.black87),
          actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _onRefresh)],
        ),
        body: Column(
          children: [
            Expanded(
              child: FutureBuilder<List<dynamic>>(
                future: _dataFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator(color: Color(0xFF3B5998)));
                  if (snapshot.hasError) return Center(child: Text('정보 로딩 실패: ${snapshot.error}'));
                  if (!snapshot.hasData || snapshot.data!.isEmpty) return const Center(child: Text('노선 정보가 없습니다.'));

                  final List<BusRouteStop> allStops = snapshot.data![0];
                  final List<BusLocation> busLocations = snapshot.data![1];
                  final Map<String, BusLocation> busLocationMap = {for (var bus in busLocations) bus.stationId: bus};

                  // 회차지 찾기 및 리스트 분할 로직
                  int turnPointIndex = allStops.indexWhere((s) => s.isTurnPoint == true);
                  if (turnPointIndex == -1) {
                    turnPointIndex = (allStops.length / 2).floor();
                  }

                  // 리스트 쪼개기
                  List<BusRouteStop> toTurnPointStops = allStops.sublist(0, turnPointIndex + 1);
                  List<BusRouteStop> toStartStops = allStops.sublist(turnPointIndex + 1);

                  // 탭 제목 결정을 위한 역 이름 추출
                  String turnPointName = toTurnPointStops.isNotEmpty ? toTurnPointStops.last.stationName : "회차지";
                  String endPointName = toStartStops.isNotEmpty ? toStartStops.last.stationName : "종점";

                  return Column(
                    children: [
                      Container(
                        color: Colors.white,
                        child: TabBar(
                          labelColor: const Color(0xFF3B5998),
                          unselectedLabelColor: Colors.grey,
                          indicatorColor: const Color(0xFF3B5998),
                          indicatorWeight: 3,
                          labelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          tabs: [
                            Tab(text: "$turnPointName 방면"),
                            Tab(text: "$endPointName 방면"),
                          ],
                        ),
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _buildRouteList(toTurnPointStops, busLocationMap, isNavMode),
                            _buildRouteList(toStartStops, busLocationMap, isNavMode),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            if (isNavMode)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, -4))],
                ),
                child: SafeArea(
                  child: ElevatedButton(
                    onPressed: _startNavigation,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3B5998),
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 56),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      elevation: 4,
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.navigation_rounded, size: 24),
                        SizedBox(width: 10),
                        Text("경로 안내 시작", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRouteList(
      List<BusRouteStop> stops,
      Map<String, BusLocation> busLocationMap,
      bool isNavMode,
      ) {
    if (stops.isEmpty) return const Center(child: Text("정류장 정보가 없습니다."));

    return ListView.builder(
      padding: const EdgeInsets.only(top: 16, bottom: 16),
      itemCount: stops.length,
      itemBuilder: (context, index) {
        final stop = stops[index];
        final busAtStation = busLocationMap[stop.stationId];

        bool isStart = isNavMode && (widget.startStation != null && stop.stationName == widget.startStation);
        bool isEnd = isNavMode && (widget.endStation != null && stop.stationName == widget.endStation);

        return _buildTimelineItem(
          stop: stop,
          bus: busAtStation,
          isFirst: index == 0,
          isLast: index == stops.length - 1,
          isStart: isStart,
          isEnd: isEnd,
        );
      },
    );
  }

  Widget _buildTimelineItem({
    required BusRouteStop stop,
    BusLocation? bus,
    required bool isFirst,
    required bool isLast,
    bool isStart = false,
    bool isEnd = false,
  }) {
    final bool isBusHere = bus != null;
    final bool isTurnPoint = stop.isTurnPoint;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 60,
            child: Column(
              children: [
                Expanded(child: Container(width: 2, color: isFirst ? Colors.transparent : Colors.grey[300])),
                SizedBox(
                  height: 40,
                  child: Center(child: _buildTimelineNode(isBusHere, isTurnPoint, isStart, isEnd)),
                ),
                Expanded(child: Container(width: 2, color: isLast ? Colors.transparent : Colors.grey[300])),
              ],
            ),
          ),
          Expanded(
            child: Container(
              margin: const EdgeInsets.only(bottom: 4, right: 16, top: 4),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: (isStart || isEnd) ? const Color(0xFFE8F0FE) : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: (isStart || isEnd) ? Border.all(color: const Color(0xFF3B5998), width: 1.5) : null,
                boxShadow: isBusHere ? [BoxShadow(color: Colors.blueAccent.withOpacity(0.1), blurRadius: 8)] : [],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          stop.stationName,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: (isStart || isEnd || isBusHere) ? FontWeight.bold : FontWeight.w500,
                            color: (isStart || isEnd) ? const Color(0xFF3B5998) : Colors.black87,
                          ),
                        ),
                      ),
                      if (isStart) _buildBadge("승차", Colors.blue),
                      if (isEnd) _buildBadge("하차", Colors.red),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text('ID: ${stop.stationId}', style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                  if (isBusHere && bus?.congestion != null)
                    Padding(padding: const EdgeInsets.only(top: 6), child: _buildCongestionBadge(bus!.congestion)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimelineNode(bool isBusHere, bool isTurnPoint, bool isStart, bool isEnd) {
    if (isBusHere) {
      return Container(
        width: 30, height: 30,
        decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: const Color(0xFF3B5998), width: 2)),
        child: const Icon(Icons.directions_bus_rounded, color: Color(0xFF3B5998), size: 16),
      );
    } else if (isStart || isEnd) {
      return Container(
        width: 16, height: 16,
        decoration: BoxDecoration(
          color: isStart ? Colors.blue : Colors.red,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4)],
        ),
      );
    } else if (isTurnPoint) {
      // 회차지 표시 아이콘 추가
      return Container(
        width: 14, height: 14,
        decoration: BoxDecoration(
            color: Colors.orange,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 2)
        ),
      );
    } else {
      return Container(width: 10, height: 10, decoration: BoxDecoration(color: Colors.grey[300], shape: BoxShape.circle));
    }
  }

  Widget _buildBadge(String text, Color color) {
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(6)),
      child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildCongestionBadge(int? congestion) {
    return const SizedBox.shrink(); // 기존 로직 유지
  }
}
// lib/models/bus_route_stop.dart

class BusRouteStop {
  final String? routeId;
  final String? routeName;
  final String? routeType;

  final String stationId;
  final String stationName;
  final int stationOrder;
  final bool isTurnPoint;

  // ⭐️ [추가] 지도 표시를 위한 좌표
  final double latitude;
  final double longitude;

  BusRouteStop({
    required this.stationId,
    required this.stationName,
    required this.stationOrder,
    required this.isTurnPoint,
    this.routeId,
    this.routeName,
    this.routeType,
    // ⭐️ 생성자에 추가
    this.latitude = 0.0,
    this.longitude = 0.0,
  });

  factory BusRouteStop.fromJson(Map<String, dynamic> json) {
    return BusRouteStop(
      routeId: json['routeId']?.toString(),
      routeName: json['routeName']?.toString() ?? '이름 없음',
      routeType: json['routeType']?.toString(),

      stationId: json['stationId'].toString(),
      stationName: json['stationName'] as String? ?? '이름 없음',
      stationOrder: json['stationOrder'] as int? ?? 0,
      isTurnPoint: json['isTurnPoint'] as bool? ?? false,

      // ⭐️ [추가] API에서 좌표 파싱 (없으면 0.0)
      // (주의: Java 백엔드 DTO에도 latitude, longitude 필드가 추가되어 있어야 값이 들어옵니다!)
      // 만약 백엔드 수정이 어렵다면, 일단 0.0으로 두고 추후 업데이트하세요.
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
class BusArrivalInfo {
  final String? routeId;
  final String? routeName;
  final String? arrivalInfo; // 예: "3분후[2번째 전]"
  final int? predictTime;
  final int? remainingStops;

  // API 필드
  final int? locationNo1;
  final int? predictTime1;

  final String? plateNo;
  final String? routeType;
  final int? congestion;

  // ⭐️ [NEW] 막차 여부 확인을 위한 필드 추가 (백엔드와 통일)
  final String? flag;

  BusArrivalInfo({
    this.routeId,
    this.routeName,
    this.arrivalInfo,
    this.predictTime,
    this.remainingStops,
    this.locationNo1,
    this.predictTime1,
    this.plateNo,
    this.routeType,
    this.congestion,
    // ⭐️ [NEW] 생성자에 flag 추가
    this.flag,
  });

  // ⭐️ [NEW] 막차 상태 반환 Getter 추가 (에러 해결: The getter 'lastBusStatus' isn't defined)
  // 0: 일반, 1: 막전(막차 전), 2: 막차
  int get lastBusStatus {
    final info = arrivalInfo ?? '';
    final flagStr = flag ?? '';

    // 백엔드에서 받은 flag나 arrivalInfo 텍스트를 기준으로 상태 판단
    if (info.contains('막차') || flagStr == 'STOP') return 2;
    if (info.contains('막전') || flagStr == 'LAST_RUN') return 1; // LAST_RUN은 예시에서 사용한 값
    return 0;
  }


  factory BusArrivalInfo.fromJson(Map<String, dynamic> json) {
    // 안전한 파싱 함수
    int? parseInt(dynamic value) {
      if (value == null) return null;
      if (value is int) return value;
      return int.tryParse(value.toString());
    }

    return BusArrivalInfo(
      routeId: json['routeId']?.toString() ?? json['route_id']?.toString(),
      routeName: json['routeName']?.toString() ?? json['route_name']?.toString(),
      arrivalInfo: json['arrivalInfo']?.toString() ?? json['arrival_info']?.toString(),

      predictTime: parseInt(json['predictTime']),
      remainingStops: parseInt(json['remainingStops']),

      locationNo1: parseInt(json['locationNo1']),
      predictTime1: parseInt(json['predictTime1']),

      plateNo: json['plateNo']?.toString() ?? json['plate_no']?.toString(),
      routeType: json['routeType']?.toString() ?? json['route_type']?.toString(),
      congestion: parseInt(json['congestion']),

      // ⭐️ [NEW] flag 필드 매핑
      flag: json['flag']?.toString(),
    );
  }
}
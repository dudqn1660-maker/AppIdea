// lib/models/bus_station.dart

class BusStation {
  final String stationId;
  final String stationName;
  // ⭐️ [수정!] String? (Nullable String)으로 변경하여 null 할당 가능
  final String? mobileNo;

  // ⭐️ [추가] 주변 검색 결과를 위해 위도/경도 필드 추가
  final double latitude;
  final double longitude;

  BusStation({
    required this.stationId,
    required this.stationName,
    this.mobileNo, // ⭐️ required 제거
    required this.latitude,
    required this.longitude,
  });

  factory BusStation.fromJson(Map<String, dynamic> json) {
    // 헬퍼 함수: JSON 값을 String?으로 안전하게 변환
    String? _parseString(dynamic value) {
      if (value == null) return null;
      String str = value.toString();
      // "정보 없음" 등의 placeholder가 빈 문자열을 의미한다면 null로 처리할 수도 있음
      return str.isEmpty ? null : str;
    }

    // Spring Boot 서버가 보낸 DTO 필드에 맞
    return BusStation(
      stationId: _parseString(json['stationId']) ?? '', // ID는 필수이므로 null이면 빈 문자열 처리
      stationName: _parseString(json['stationName']) ?? '이름 없음',

      // ⭐️ [수정!] mobileNo를 String?으로 안전하게 파싱
      mobileNo: _parseString(json['mobileNo']),

      // ⭐️ [추가] 서버에서 받은 double 값을 안전하게 파싱 (num -> double)
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
    );
  }
}
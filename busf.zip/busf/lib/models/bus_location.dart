class BusLocation {
  final String routeId;
  final String stationId;
  final int stationOrder;
  final String plateNo;
  final double latitude;
  final double longitude;
  final int? congestion;

  // ⭐️ 편의성 Getter (화면에서 .lat / .lng로 접근 가능하게 함)
  double get lat => latitude;
  double get lng => longitude;

  BusLocation({
    required this.routeId,
    required this.stationId,
    required this.stationOrder,
    required this.plateNo,
    required this.latitude,
    required this.longitude,
    this.congestion,
  });

  factory BusLocation.fromJson(Map<String, dynamic> json) {
    // 데이터 파싱 헬퍼 함수
    int? _parseInt(dynamic value) {
      if (value == null) return null;
      if (value is int) return value;
      return int.tryParse(value.toString());
    }

    double? _parseDouble(dynamic value) {
      if (value == null) return null;
      if (value is double) return value;
      if (value is num) return value.toDouble();
      return double.tryParse(value.toString());
    }

    // ⭐️ [핵심] 좌표값 찾기 (가능한 모든 키값 다 뒤짐)
    double lat = _parseDouble(json['latitude']) ??
        _parseDouble(json['lat']) ??
        _parseDouble(json['gpsY']) ??
        _parseDouble(json['y']) ??
        0.0;

    double lng = _parseDouble(json['longitude']) ??
        _parseDouble(json['lng']) ??
        _parseDouble(json['gpsX']) ??
        _parseDouble(json['x']) ??
        0.0;

    // 디버깅용: 만약 좌표가 0.0이면 들어온 데이터를 로그에 찍음
    if (lat == 0.0 || lng == 0.0) {
      print("⚠️ 좌표 파싱 실패 (JSON 데이터 확인): $json");
    }

    return BusLocation(
      routeId: json['routeId']?.toString() ?? '',
      stationId: json['stationId']?.toString() ?? '',
      stationOrder: _parseInt(json['stationOrder']) ?? 0,
      plateNo: json['plateNo']?.toString() ?? '정보 없음',
      latitude: lat,
      longitude: lng,
      congestion: _parseInt(json['congestion']),
    );
  }
}
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
// (경로 확인)
import 'package:bus/models/bus_station.dart';

class FavoriteService {
  // SharedPreferences에 저장할 때 사용할 고유 키
  static const _favoritesKey = 'favoriteStations';

  // 1. 즐겨찾기 목록 불러오기
  Future<List<BusStation>> getFavorites() async {
    final prefs = await SharedPreferences.getInstance();

    // 휴대폰에서 '_favoritesKey'로 저장된 문자열 목록을 가져옴
    final List<String> favoriteStrings = prefs.getStringList(_favoritesKey) ?? [];

    // 문자열 목록(JSON)을 -> BusStation 객체 목록으로 변환
    return favoriteStrings
        .map((jsonString) => BusStation.fromJson(jsonDecode(jsonString)))
        .toList();
  }

  // 2. 즐겨찾기 추가하기
  Future<void> addFavorite(BusStation station) async {
    final prefs = await SharedPreferences.getInstance();

    // 현재 즐겨찾기 목록 불러오기
    List<BusStation> favorites = await getFavorites();

    // (중복 방지) 이미 목록에 있는지 확인
    if (!favorites.any((s) => s.stationId == station.stationId)) {
      favorites.add(station); // 목록에 추가

      // BusStation 객체 목록을 -> JSON 문자열 목록으로 변환
      List<String> favoriteStrings = favorites
          .map((s) => jsonEncode({
        'stationId': s.stationId,
        'stationName': s.stationName,
        'mobileNo': s.mobileNo,
      }))
          .toList();

      // 휴대폰에 저장
      await prefs.setStringList(_favoritesKey, favoriteStrings);
    }
  }

  // 3. 즐겨찾기 삭제하기
  Future<void> removeFavorite(String stationId) async {
    final prefs = await SharedPreferences.getInstance();

    List<BusStation> favorites = await getFavorites();

    // stationId가 일치하는 항목을 목록에서 제거
    favorites.removeWhere((s) => s.stationId == stationId);

    // 다시 문자열로 변환
    List<String> favoriteStrings = favorites
        .map((s) => jsonEncode({
      'stationId': s.stationId,
      'stationName': s.stationName,
      'mobileNo': s.mobileNo,
    }))
        .toList();

    // 휴대폰에 저장
    await prefs.setStringList(_favoritesKey, favoriteStrings);
  }

  // (부가 기능) 이미 즐겨찾기했는지 확인
  Future<bool> isFavorite(String stationId) async {
    List<BusStation> favorites = await getFavorites();
    return favorites.any((s) => s.stationId == stationId);
  }
}
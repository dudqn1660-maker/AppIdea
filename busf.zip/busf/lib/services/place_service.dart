// lib/services/place_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;

class Place {
  final String placeName;
  final String address;
  final double lat;
  final double lng;

  Place({
    required this.placeName,
    required this.address,
    required this.lat,
    required this.lng,
  });

  factory Place.fromJson(Map<String, dynamic> json) {
    return Place(
      placeName: json['place_name'] ?? '',
      address: json['address_name'] ?? '',
      // 카카오 API는 y=위도(lat), x=경도(lng)를 사용합니다.
      lat: double.parse(json['y']),
      lng: double.parse(json['x']),
    );
  }
}

class PlaceService {
  // ⭐️ [수정] _를 제거하고 공개하여 GeolocationService에서 접근 가능하도록 합니다.
  // 이 키가 현재 파일 외부에서도 필요합니다.
  static const String kakaoApiKey = 'KakaoAK ef861cc559195b6ecbf44129e7da85ec'; // 🚨 본인의 카카오 키로 변경해야 합니다.

  Future<List<Place>> searchPlaces(String query) async {
    if (query.isEmpty) return [];

    // 1. 검색어에 '경기' 자동 추가
    String optimizedQuery = query;
    if (!query.contains('경기')) {
      optimizedQuery = "경기 $query";
    }

    final url = 'https://dapi.kakao.com/v2/local/search/keyword.json?query=$optimizedQuery';

    final response = await http.get(
      Uri.parse(url),
      // ⭐️ [수정] 변경된 키 이름(kakaoApiKey) 사용
      headers: {'Authorization': kakaoApiKey},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List documents = data['documents'];

      return documents
          .where((json) {
        // 2. 주소에 '경기'가 포함된 것만 필터링
        final String address = json['address_name'] ?? '';
        return address.contains('경기');
      })
          .map((json) => Place.fromJson(json))
          .toList();
    } else {
      // 키가 틀리면 여기서 에러가 납니다 (401 Unauthorized)
      print('카카오 API 오류: ${response.statusCode} / ${response.body}');
      throw Exception('장소 검색 실패: ${response.statusCode} (API 키를 확인하세요)');
    }
  }
}
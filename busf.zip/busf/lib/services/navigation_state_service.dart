import 'package:flutter/foundation.dart';
import 'package:bus/models/bus_arrival_info.dart';

class NavigationStateService extends ChangeNotifier {
  static final NavigationStateService _instance = NavigationStateService._internal();
  factory NavigationStateService() => _instance;
  NavigationStateService._internal();

  bool _isNavigating = false;
  bool get isNavigating => _isNavigating;

  BusArrivalInfo? _currentBus;
  BusArrivalInfo? get currentBus => _currentBus;

  String? _endStation;
  String? get endStation => _endStation;

  // ⭐️ [NEW] 탑승 여부 상태 추가
  bool _isBoarded = false;
  bool get isBoarded => _isBoarded;

  // ⭐️ [NEW] 탑승 상태 변경 함수
  void setBoarded(bool value) {
    _isBoarded = value;
    notifyListeners();
  }

  void startNavigation(BusArrivalInfo bus, String endStation) {
    _isNavigating = true;
    _currentBus = bus;
    _endStation = endStation;
    _isBoarded = false; // ⭐️ 새로 시작할 땐 탑승 안 함으로 초기화
    notifyListeners();
  }

  void stopNavigation() {
    _isNavigating = false;
    _currentBus = null;
    _endStation = null;
    _isBoarded = false; // ⭐️ 종료 시 초기
    notifyListeners();
  }
}
// lib/services/geolocation_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart'; // ⭐️ GPS 위치 정보 획득 패키지
import 'package:bus/services/place_service.dart'; // ⭐️ Place 모델과 Kakao API Key 재활용

class GeolocationService {
  // place_service.dart에 정의된 카카오 REST API 키를 사용합니다.
  static const String _kakaoApiKey = PlaceService.kakaoApiKey;

  // 1. 현재 GPS 위치 (위도, 경도)를 가져옵니다.
  Future<Position> getCurrentPosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // 위치 서비스 활성화 여부 체크
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('위치 서비스를 활성화해주세요.');
    }

    // 위치 권한 체크
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('위치 권한이 거부되었습니다. 설정에서 권한을 허용해주세요.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error('위치 권한이 영구적으로 거부되었습니다. 설정에서 권한을 변경해주세요.');
    }

    // 위치 정보 가져오기
    return await Geolocator.getCurrentPosition(
      // 높은 정확도를 요청하지만, 실패 시 정확도가 낮은 위치 정보라도 반환하도록 합니다.
      desiredAccuracy: LocationAccuracy.high,
      forceAndroidLocationManager: true, // 안드로이드에서 정확도 이슈를 보정
    );
  }

  // 2. 현재 GPS 위치를 Place 객체(주소와 이름)로 변환합니다.
  Future<Place> getCurrentLocationAsPlace() async {
    final position = await getCurrentPosition();

    // 카카오 API: 좌표를 주소로 변환 (Reverse Geocoding)
    // 카카오는 x=경도, y=위도 순서를 사용합니다.
    final url = 'https://dapi.kakao.com/v2/local/geo/coord2address.json?x=${position.longitude}&y=${position.latitude}';

    final response = await http.get(
      Uri.parse(url),
      headers: {'Authorization': _kakaoApiKey},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List documents = data['documents'];

      if (documents.isEmpty) {
        // 주소를 찾지 못해도 좌표는 유효하므로, 좌표를 Place에 담아 반환합니다.
        return Place(placeName: "현재 위치", address: "주소를 찾을 수 없습니다.", lat: position.latitude, lng: position.longitude);
      }

      final addressInfo = documents[0]['address'];

      // Place 객체로 변환하여 반환
      return Place(
        placeName: "현재 위치",
        // 도로명 주소가 있으면 사용하고, 없으면 지번 주소를 사용합니다.
        address: addressInfo['road_address']?['address_name'] ?? addressInfo['address_name'] ?? '주소 정보 없음',
        lat: position.latitude,
        lng: position.longitude,
      );
    } else {
      throw Exception('좌표-주소 변환 실패: ${response.statusCode}');
    }
  }
}
// src/main/java/com/example/bus/dto/BusStationDto.java
package com.example.bus.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusStationDto {
    private String stationId;
    private String stationName;
    private String mobileNo;

    // ⭐️ 추가: 위치 기반 검색 결과를 위해 위도와 경도 필드 추가
    private double latitude;
    private double longitude;
}
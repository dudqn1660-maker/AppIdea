package com.example.bus.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusArrivalInfo {
    private String routeId;
    private String routeName;

    private Integer predictTime; // 예상 시간 (분)
    private String arrivalInfo;  // "N분 후" 텍스트

    private String plateNo;      // 차량 번호
    private Integer routeTypeCd; // 노선 유형 코드
    private String routeType;    // 노선 유형 명칭 (일반, 마을 등)

    private Integer congestion;  // 혼잡도

    // ⭐️ [추가됨] 남은 정류장 수 (앱에서 'N번째 전' 표시할 때 사용)
    private Integer locationNo1;

    // ⭐️ [추가됨] 버스 상태 플래그 (STOP: 막차/운행종료, WAIT: 회차지대기 등)
    // 앱에서 '막차' 배지를 띄우기 위해 필수입니다.
    private String flag;
}
// src/main/java/com/example/bus/config/CorsConfig.java
package com.example.bus.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * CORS (Cross-Origin Resource Sharing) 설정을 위한 Configuration 클래스.
 * 개발 환경에서 Flutter 앱과의 연동을 원활하게 하기 위해 로컬호스트의 모든 포트를 허용합니다.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // "/api/**" 경로로 들어오는 모든 요청에 대해 CORS 설정 적용
        registry.addMapping("/api/**")

                // ⭐️ 로컬 개발 환경의 모든 포트를 허용 (Flutter 포트 변경 시에도 작동)
                // allowedOrigins에 포트 번호 대신 와일드카드(*)를 사용하여 로컬호스트/127.0.0.1의 모든 포트 허용
                .allowedOrigins(
                        "http://localhost:*",
                        "http://127.0.0.1:*",
                        "https://localhost:*",
                        "https://127.0.0.1:*"
                )

                // 허용할 HTTP 메서드 정의 (GET, POST, PUT, DELETE, OPTIONS)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")

                // 요청에 모든 헤더 허용
                .allowedHeaders("*")

                // 인증 정보 (쿠키, HTTP 인증)를 요청에 포함할 수 있도록 허용
                // allowedOrigins에 와일드카드 (*) 대신 구체적인 주소를 사용했기 때문에 true 설정 가능
                .allowCredentials(true)

                // 브라우저가 preflight 요청 결과를 캐시할 시간 (초)
                .maxAge(3600);
    }
}
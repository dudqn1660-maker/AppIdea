// src/main/java/com/example/bus/BusAppApplication.java
package com.example.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
// import 문 제거: org.springframework.web.servlet.config.annotation.WebMvcConfigurer 등

@SpringBootApplication
public class BusApplication {

    public static void main(String[] args) {
        SpringApplication.run(BusApplication.class, args);
    }

    // ⚠️ 경고: 기존에 추가했던 corsConfigurer() @Bean 메서드는 여기서 제거합니다.
    // 설정 파일이 별도로 존재하므로 여기서 중복으로 정의할 필요가 없습니다.
}
package com.example.bus.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BusLocationDto {
    private String stationId;
    private int stationOrder;
    private String plateNo;

    // ⭐️ [필수 확인] 이 필드들이 있어야 합니다!
    private double latitude;
    private double longitude;

    private Integer congestion;

    // ⭐️ [추가] routeId 필드도 있으면 좋습니다 (앱에서 필터링용)
    private String routeId;
}
package com.example.bus.controller;

import com.example.bus.dto.BusStationDto;
import com.example.bus.dto.BusArrivalInfo;
import com.example.bus.dto.BusRouteStopDto;
import com.example.bus.dto.BusLocationDto;
import com.example.bus.service.BusApiService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Collections;

import lombok.extern.slf4j.Slf4j; // ⭐️ [추가] Logger 사용을 위한 import

@Slf4j // ⭐️ [추가] Lombok을 이용해 logger 객체 (log) 자동 생성
@RestController
@RequestMapping("/api")
public class BusController {

    private final BusApiService busApiService;

    public BusController(BusApiService busApiService) {
        this.busApiService = busApiService;
    }

    // 1. 정류소 검색 API
    @GetMapping("/stations/search")
    public List<BusStationDto> searchStations(@RequestParam String keyword) {
        return busApiService.searchStation(keyword);
    }

    // 5. 주변 정류소 검색 API (⭐️ [수정] log.info() 사용)
    @GetMapping("/stations/nearby")
    public List<BusStationDto> searchNearbyStations(
            @RequestParam double lat,
            @RequestParam double lon,
            @RequestParam(required = false, defaultValue = "500") int radius) {

        // ⭐️ [수정] System.out.println 대신 log.info() 사용
        log.info("[BusController] /stations/nearby 호출됨 - lat: {}, lon: {}, radius: {}", lat, lon, radius);

        // ⭐️ Flutter 앱에서 받은 실제 좌표와 반경으로 API 서비스 호출
        return busApiService.searchNearbyStations(lat, lon, radius);
    }

    // 2. 버스 도착 정보 API
    @GetMapping("/stations/{stationId}/arrivals")
    public ResponseEntity<List<BusArrivalInfo>> getArrivals(@PathVariable String stationId) {
        try {
            List<BusArrivalInfo> arrivals = busApiService.fetchBusArrival(stationId);
            return ResponseEntity.ok(arrivals);
        } catch (Exception e) {
            // ⭐️ [수정] System.err.println 대신 log.error() 사용
            log.error("Controller 레벨에서 도착 정보 처리 중 오류 발생: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.emptyList());
        }
    }

    // 3. 노선 ID로 정류소 목록을 가져오는 API
    @GetMapping("/routes/{routeId}/stops")
    public List<BusRouteStopDto> getRouteStops(@PathVariable String routeId) {
        return busApiService.getBusRoute(routeId);
    }

    // 4. 노선 ID로 실시간 버스 위치 목록을 가져오는 API
    @GetMapping("/routes/{routeId}/locations")
    public List<BusLocationDto> getBusLocations(@PathVariable String routeId) {
        return busApiService.getBusLocations(routeId);
    }
}